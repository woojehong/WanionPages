local _, WA = ...

WA.CalendarInviteQueue = {
  state = "idle",
  pending = {},
  completed = 0,
  skipped = 0,
  failed = {},
}

local function cancelTimer(queue)
  if queue.timer and queue.timer.Cancel then queue.timer:Cancel() end
  queue.timer = nil
end

function WA.CalendarInviteQueue:Notify(message, isError)
  WA.Diagnostics:Log(isError and "ERROR" or "INFO", "CALINV", message)
  WA:Emit("CALENDAR_INVITE_STATUS", message, isError)
  WA:Emit("ACTION_STATUS", message, isError)
end

function WA.CalendarInviteQueue:Stop(message, isError)
  cancelTimer(self)
  self.current = nil
  self.state = isError and "error" or "idle"
  if message then self:Notify(message, isError) end
end

function WA.CalendarInviteQueue:Start(attendees)
  if InCombatLockdown and InCombatLockdown() then
    return self:Notify("전투 중에는 달력 초대를 시작할 수 없습니다.", true)
  end
  if not C_Calendar or type(C_Calendar.EventInvite) ~= "function" then
    return self:Notify("이 클라이언트는 달력 초대 API를 지원하지 않습니다.", true)
  end
  if C_Calendar.CanSendInvite then
    local ok, canSend = pcall(C_Calendar.CanSendInvite)
    if not ok or not canSend then
      return self:Notify("먼저 WoW 기본 달력에서 일정을 저장하고 해당 일정을 열어주세요.", true)
    end
  end
  self:Stop()
  self.pending, self.failed = {}, {}
  self.completed, self.skipped = 0, 0
  local player = WA.Identity:FromUnit("player")
  local seen = {}
  for i = 1, #(attendees or {}) do
    local identity = attendees[i]
    if identity and not seen[identity.key] then
      seen[identity.key] = true
      if player and identity.key == player.key then
        self.skipped = self.skipped + 1
      else
        self.pending[#self.pending + 1] = identity
      end
    end
  end
  if #self.pending == 0 then return self:Notify("초대할 확정 인원이 없습니다.", false) end
  self.state = "running"
  self:Notify(("달력 초대 시작: %d명 (본인·중복 제외 %d명)"):format(#self.pending, self.skipped), false)
  self:Advance()
end

function WA.CalendarInviteQueue:Advance()
  if self.state ~= "running" or self.current then return end
  if #self.pending == 0 then
    return self:Stop(("달력 초대 완료: 요청 %d명, 실패 %d명, 제외 %d명"):format(self.completed, #self.failed, self.skipped), #self.failed > 0)
  end
  if InCombatLockdown and InCombatLockdown() then
    self.state = "paused-combat"
    return self:Notify("전투 종료까지 달력 초대를 일시 정지합니다.", false)
  end
  if C_Calendar.CanSendInvite then
    local ok, canSend = pcall(C_Calendar.CanSendInvite)
    if not ok or not canSend then
      return self:Stop("현재 열린 달력 일정에 초대할 수 없습니다. 일정이 저장되어 열려 있는지 확인하세요.", true)
    end
  end
  self.current = table.remove(self.pending, 1)
  local ok, err = pcall(C_Calendar.EventInvite, self.current.fullName)
  if not ok then
    self.failed[#self.failed + 1] = { identity = self.current, reason = tostring(err) }
    self.current = nil
    return self:Stop("달력 초대 API가 차단되었습니다: " .. tostring(err), true)
  end
  self.completed = self.completed + 1
  self:Notify("달력 초대 요청: " .. self.current.fullName, false)
  self.timer = C_Timer.NewTimer(1.5, function() WA.CalendarInviteQueue:OnReady() end)
end

function WA.CalendarInviteQueue:OnReady()
  cancelTimer(self)
  if self.state ~= "running" then return end
  self.current = nil
  self:Advance()
end

function WA.CalendarInviteQueue:RetryFailed()
  if #self.failed == 0 then return self:Notify("다시 시도할 달력 초대가 없습니다.", false) end
  local attendees = {}
  for i = 1, #self.failed do attendees[#attendees + 1] = self.failed[i].identity end
  self:Start(attendees)
end

function WA.CalendarInviteQueue:Initialize()
  local frame = CreateFrame("Frame")
  frame:RegisterEvent("CALENDAR_ACTION_PENDING")
  frame:RegisterEvent("PLAYER_REGEN_ENABLED")
  frame:SetScript("OnEvent", function(_, eventName, pending)
    if eventName == "CALENDAR_ACTION_PENDING" and WA.CalendarInviteQueue.state == "running" and pending == false then
      WA.CalendarInviteQueue:OnReady()
    elseif eventName == "PLAYER_REGEN_ENABLED" and WA.CalendarInviteQueue.state == "paused-combat" then
      WA.CalendarInviteQueue.state = "running"
      WA.CalendarInviteQueue:Advance()
    end
  end)
  self.frame = frame
end
