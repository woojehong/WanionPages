local _, WA = ...

WA.UI = { panels = {}, inputs = {} }

local C = {
  bg = { 0.026, 0.027, 0.045, 0.985 },
  surface = { 0.052, 0.054, 0.082, 1 },
  surfaceHover = { 0.082, 0.078, 0.128, 1 },
  line = { 0.19, 0.19, 0.28, 1 },
  violet = { 0.54, 0.44, 1, 1 },
  violetSoft = { 0.22, 0.17, 0.42, 1 },
  text = { 0.94, 0.94, 0.98, 1 },
  sub = { 0.64, 0.65, 0.74, 1 },
  danger = { 0.95, 0.40, 0.45, 1 },
}

local function backdrop(frame, bg, line)
  frame:SetBackdrop({
    bgFile = "Interface\\Buttons\\WHITE8X8",
    edgeFile = "Interface\\Buttons\\WHITE8X8",
    edgeSize = 1,
    insets = { left = 0, right = 0, top = 0, bottom = 0 },
  })
  frame:SetBackdropColor(unpack(bg or C.surface))
  frame:SetBackdropBorderColor(unpack(line or C.line))
end

local function font(parent, size, color, flags)
  local value = parent:CreateFontString(nil, "OVERLAY")
  value:SetFont("Fonts\\2002.TTF", size or 12, flags or "")
  value:SetTextColor(unpack(color or C.text))
  return value
end

local function button(parent, text, width, onClick)
  local control = CreateFrame("Button", nil, parent, "BackdropTemplate")
  control:SetSize(width or 100, 30)
  backdrop(control)
  control.label = font(control, 12, C.text)
  control.label:SetPoint("CENTER", 0, 0)
  control.label:SetText(text)
  control:SetScript("OnClick", onClick)
  control:SetScript("OnEnter", function(self)
    self:SetBackdropColor(unpack(C.surfaceHover))
    self:SetBackdropBorderColor(unpack(C.violet))
  end)
  control:SetScript("OnLeave", function(self)
    if self.__wanionActive then
      self:SetBackdropColor(unpack(C.violetSoft))
      self:SetBackdropBorderColor(unpack(C.violet))
    else
      self:SetBackdropColor(unpack(C.surface))
      self:SetBackdropBorderColor(unpack(C.line))
    end
  end)
  control.SetWanionActive = function(self, active)
    self.__wanionActive = active == true
    self:SetBackdropColor(unpack(self.__wanionActive and C.violetSoft or C.surface))
    self:SetBackdropBorderColor(unpack(self.__wanionActive and C.violet or C.line))
  end
  return control
end

local function editBox(parent, height, width)
  local shell = CreateFrame("Frame", nil, parent, "BackdropTemplate")
  shell:SetHeight(height)
  backdrop(shell, C.bg, C.line)
  local scroll = CreateFrame("ScrollFrame", nil, shell)
  scroll:SetPoint("TOPLEFT", 10, -9)
  scroll:SetPoint("BOTTOMRIGHT", -15, 9)
  local edit = CreateFrame("EditBox", nil, scroll)
  edit:EnableMouse(true)
  edit:EnableKeyboard(true)
  edit:SetMultiLine(true)
  edit:SetAutoFocus(false)
  edit:SetFont("Fonts\\2002.TTF", 12, "")
  edit:SetTextColor(unpack(C.text))
  edit:SetJustifyH("LEFT")
  edit:SetJustifyV("TOP")
  edit:SetWidth(width or 500)
  edit:SetHeight(math.max(1, height - 18))
  edit:SetPoint("TOPLEFT", scroll, "TOPLEFT", 0, 0)
  scroll:SetScrollChild(edit)
  edit:SetFrameLevel(scroll:GetFrameLevel() + 1)
  edit:SetMaxLetters(0)
  edit:SetScript("OnEscapePressed", edit.ClearFocus)
  edit:SetScript("OnMouseDown", function(self) self:SetFocus() end)
  scroll:SetScript("OnMouseDown", function() edit:SetFocus() end)
  local rail = shell:CreateTexture(nil, "ARTWORK")
  rail:SetColorTexture(C.line[1], C.line[2], C.line[3], 0.75)
  rail:SetPoint("TOPRIGHT", -6, -9)
  rail:SetPoint("BOTTOMRIGHT", -6, 9)
  rail:SetWidth(2)
  local thumb = shell:CreateTexture(nil, "OVERLAY")
  thumb:SetColorTexture(unpack(C.violet))
  thumb:SetPoint("TOPRIGHT", -5, -9)
  thumb:SetSize(4, 34)
  local function refresh()
    local range = math.max(0, edit:GetHeight() - scroll:GetHeight())
    local current = math.min(range, scroll:GetVerticalScroll() or 0)
    local travel = math.max(0, scroll:GetHeight() - 34)
    thumb:ClearAllPoints()
    thumb:SetPoint("TOPRIGHT", shell, "TOPRIGHT", -5, -9 - (range > 0 and current / range * travel or 0))
    thumb:SetShown(range > 0)
  end
  edit:SetScript("OnTextChanged", function(self)
    local textHeight = math.max(height - 18, self:GetStringHeight() + 18)
    self:SetHeight(textHeight)
    refresh()
  end)
  scroll:EnableMouseWheel(true)
  scroll:SetScript("OnMouseWheel", function(self, delta)
    local range = math.max(0, edit:GetHeight() - self:GetHeight())
    self:SetVerticalScroll(math.max(0, math.min(range, self:GetVerticalScroll() - delta * 28)))
    refresh()
  end)
  scroll:SetScript("OnSizeChanged", refresh)
  return shell, edit
end

function WA.UI:SetStatus(message, isError)
  if not self.status then return end
  local color = isError and "|cffff6666" or "|cff9ad3a0"
  self.status:SetText(color .. tostring(message) .. "|r")
end

function WA.UI:SelectTab(tabName)
  for name, panel in pairs(self.panels) do panel:SetShown(name == tabName) end
  for name, control in pairs(self.tabButtons or {}) do control:SetWanionActive(name == tabName) end
  self.activeTab = tabName
end

function WA.UI:SetInput(tabName, value)
  local edit = self.inputs[tabName]
  if edit then
    edit:SetText(value or "")
    edit:HighlightText()
    edit:SetFocus()
  end
end

function WA.UI:GetInput(tabName)
  local edit = self.inputs[tabName]
  return edit and edit:GetText() or ""
end

function WA.UI:Toggle()
  if not self.frame then return end
  self.frame:SetShown(not self.frame:IsShown())
end

function WA.UI:CreateCodePanel(parent, tabName, hint)
  local panel = CreateFrame("Frame", nil, parent)
  panel:SetAllPoints(parent)
  local label = font(panel, 12, C.sub)
  label:SetPoint("TOPLEFT", 12, -12)
  label:SetText(hint)
  local scroll, edit = editBox(panel, 190)
  scroll:SetPoint("TOPLEFT", 12, -36)
  scroll:SetPoint("TOPRIGHT", -28, -36)
  self.inputs[tabName] = edit
  return panel
end

local function clamp(value, low, high)
  value = tonumber(value) or low
  if value < low then return low end
  if value > high then return high end
  return value
end

local function toUIParentCoordinate(value, sourceFrame)
  if not value then return nil end
  local sourceScale = sourceFrame and sourceFrame.GetEffectiveScale and sourceFrame:GetEffectiveScale() or 1
  local parentScale = UIParent and UIParent.GetEffectiveScale and UIParent:GetEffectiveScale() or 1
  if not sourceScale or sourceScale <= 0 or not parentScale or parentScale <= 0 then return value end
  return value * sourceScale / parentScale
end

function WA.UI:SetCalendarStatus(message, isError)
  if not self.calendarStatus then return end
  local color = isError and "|cffff6666" or "|cff9ad3a0"
  self.calendarStatus:SetText(color .. tostring(message or "") .. "|r")
end

function WA.UI:SaveCalendarPanelPosition()
  local frame = self.calendarFrame
  if not frame or not WA.db or not WA.db.ui then return end
  local left, bottom = frame:GetLeft(), frame:GetBottom()
  local uiWidth, uiHeight = UIParent:GetWidth(), UIParent:GetHeight()
  if not left or not bottom or not uiWidth or not uiHeight then return end

  local maxLeft = math.max(0, uiWidth - frame:GetWidth())
  local maxBottom = math.max(0, uiHeight - frame:GetHeight())
  left = clamp(left, 0, maxLeft)
  bottom = clamp(bottom, 0, maxBottom)
  WA.db.ui.calendarPanel = {
    left = left,
    bottom = bottom,
    xRatio = maxLeft > 0 and left / maxLeft or 0,
    yRatio = maxBottom > 0 and bottom / maxBottom or 0,
  }
end

function WA.UI:RefreshCalendarPanelPosition()
  local frame = self.calendarFrame
  if not frame or not UIParent then return end
  local uiWidth, uiHeight = UIParent:GetWidth(), UIParent:GetHeight()
  if not uiWidth or not uiHeight or uiWidth <= 0 or uiHeight <= 0 then return end

  local maxLeft = math.max(0, uiWidth - frame:GetWidth())
  local maxBottom = math.max(0, uiHeight - frame:GetHeight())
  local saved = WA.db and WA.db.ui and WA.db.ui.calendarPanel
  local left, bottom
  if type(saved) == "table" then
    if tonumber(saved.xRatio) and tonumber(saved.yRatio) then
      left = clamp(saved.xRatio, 0, 1) * maxLeft
      bottom = clamp(saved.yRatio, 0, 1) * maxBottom
    else
      left = clamp(saved.left, 0, maxLeft)
      bottom = clamp(saved.bottom, 0, maxBottom)
    end
  elseif CalendarFrame and CalendarFrame.GetLeft and CalendarFrame.GetRight and CalendarFrame.GetTop then
    local calendarLeft = toUIParentCoordinate(CalendarFrame:GetLeft(), CalendarFrame) or 0
    local calendarRight = toUIParentCoordinate(CalendarFrame:GetRight(), CalendarFrame) or 0
    local calendarTop = toUIParentCoordinate(CalendarFrame:GetTop(), CalendarFrame) or uiHeight
    local rightDock = calendarRight + 8
    local leftDock = calendarLeft - frame:GetWidth() - 8
    if rightDock + frame:GetWidth() <= uiWidth then
      left = rightDock
    elseif leftDock >= 0 then
      left = leftDock
    else
      left = clamp(rightDock, 0, maxLeft)
    end
    bottom = calendarTop - frame:GetHeight()
    left = clamp(left, 0, maxLeft)
    bottom = clamp(bottom, 0, maxBottom)
  else
    left = maxLeft
    bottom = maxBottom
  end

  frame:ClearAllPoints()
  frame:SetPoint("BOTTOMLEFT", UIParent, "BOTTOMLEFT", left, bottom)
end

function WA.UI:ResetCalendarPanelPosition()
  if WA.db and WA.db.ui then WA.db.ui.calendarPanel = nil end
  self:RefreshCalendarPanelPosition()
  self:SetCalendarStatus("기본 달력 옆 기본 위치로 복귀했습니다.", false)
end

function WA.UI:BuildCalendarPanel()
  if self.calendarFrame then return self.calendarFrame end
  if InCombatLockdown and InCombatLockdown() then return nil end

  local frame = CreateFrame("Frame", "WanionAssistCalendarPanel", UIParent, "BackdropTemplate")
  frame:SetSize(380, 462)
  frame:SetFrameStrata("HIGH")
  frame:SetToplevel(true)
  frame:SetMovable(true)
  frame:SetClampedToScreen(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  backdrop(frame, C.bg, C.violetSoft)
  frame:Hide()
  self.calendarFrame = frame

  frame:SetScript("OnDragStart", function(control)
    if InCombatLockdown and InCombatLockdown() then
      WA.UI:SetCalendarStatus("전투 중에는 패널을 이동할 수 없습니다.", true)
      return
    end
    control.__wanionDragging = true
    control:StartMoving()
  end)
  frame:SetScript("OnDragStop", function(control)
    control:StopMovingOrSizing()
    if control.__wanionDragging then
      control.__wanionDragging = nil
      WA.UI:SaveCalendarPanelPosition()
      WA.UI:RefreshCalendarPanelPosition()
    end
  end)
  frame:SetScript("OnMouseDown", function(_, mouseButton)
    if mouseButton == "RightButton" then WA.UI:ResetCalendarPanelPosition() end
  end)

  local titleBackground = frame:CreateTexture(nil, "BACKGROUND")
  titleBackground:SetPoint("TOPLEFT", 1, -1)
  titleBackground:SetPoint("TOPRIGHT", -1, -1)
  titleBackground:SetHeight(34)
  titleBackground:SetColorTexture(0.025, 0.025, 0.075, 1)

  local title = font(frame, 15, C.text, "OUTLINE")
  title:SetPoint("TOPLEFT", 12, -9)
  title:SetText("와니온 달력 도우미")
  local resetHint = font(frame, 10, C.sub)
  resetHint:SetPoint("TOPRIGHT", -10, -12)
  resetHint:SetText("빈 곳 우클릭: 위치 복귀")

  local hint = font(frame, 11, C.sub)
  hint:SetPoint("TOPLEFT", 12, -48)
  hint:SetPoint("TOPRIGHT", -12, -48)
  hint:SetJustifyH("LEFT")
  hint:SetText("WANION1 CAL 코드를 붙여넣고 미리 본 뒤 기본 작성 화면을 여세요.")

  local scroll, edit = editBox(frame, 190, 336)
  scroll:SetPoint("TOPLEFT", 12, -78)
  scroll:SetPoint("TOPRIGHT", -28, -78)
  self.inputs.calendar = edit

  local previewText = font(frame, 11, C.text)
  previewText:SetPoint("TOPLEFT", 12, -278)
  previewText:SetPoint("TOPRIGHT", -12, -278)
  previewText:SetHeight(42)
  previewText:SetJustifyH("LEFT")
  previewText:SetJustifyV("TOP")
  previewText:SetWordWrap(true)
  previewText:SetText("아직 미리 본 일정이 없습니다.")
  self.calendarPreview = previewText

  local previewButton = button(frame, "내용 미리보기", 120, function()
    local message, err = WA.Controller:PreviewCalendar(WA.UI:GetInput("calendar"))
    previewText:SetText(message or err or "미리보기에 실패했습니다.")
    WA.UI:SetCalendarStatus(message or err, err ~= nil)
  end)
  previewButton:SetPoint("BOTTOMLEFT", 12, 78)

  local createButton = button(frame, "기본 달력에서 작성", 150, function()
    WA.Controller:OpenCalendar(WA.UI:GetInput("calendar"))
  end)
  createButton:SetPoint("LEFT", previewButton, "RIGHT", 8, 0)

  local inviteButton = button(frame, "확정 명단 초대", 166, function()
    local parsed, err = WA.Protocol:ParseCalendar(WA.UI:GetInput("calendar"))
    if not parsed then return WA.UI:SetCalendarStatus(err, true) end
    WA.Calendar.currentEvent = parsed
    WA.CalendarInviteQueue:Start(parsed.attendees)
  end)
  inviteButton:SetPoint("BOTTOMLEFT", 12, 46)

  local retryButton = button(frame, "실패 명단 재시도", 120, function()
    WA.CalendarInviteQueue:RetryFailed()
  end)
  retryButton:SetPoint("LEFT", inviteButton, "RIGHT", 8, 0)

  self.calendarStatus = font(frame, 11, C.sub)
  self.calendarStatus:SetPoint("BOTTOMLEFT", 12, 14)
  self.calendarStatus:SetPoint("BOTTOMRIGHT", -12, 14)
  self.calendarStatus:SetJustifyH("LEFT")
  self.calendarStatus:SetText("|cff8a70ff일정은 자동 저장되지 않습니다.|r")

  WA:On("ACTION_STATUS", function(message, isError) WA.UI:SetCalendarStatus(message, isError) end)
  self:RefreshCalendarPanelPosition()
  if self.pendingCalendarInput then
    self:SetInput("calendar", self.pendingCalendarInput)
    self.pendingCalendarInput = nil
  end
  return frame
end

function WA.UI:Build()
  if self.frame then return end
  local frame = CreateFrame("Frame", "WanionAssistFrame", UIParent, "BackdropTemplate")
  frame:SetSize(580, 430)
  frame:SetPoint("CENTER")
  frame:SetMovable(true)
  frame:EnableMouse(true)
  frame:RegisterForDrag("LeftButton")
  frame:SetScript("OnDragStart", frame.StartMoving)
  frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
  frame:SetClampedToScreen(true)
  backdrop(frame, C.bg, C.violetSoft)
  frame:Hide()
  self.frame = frame

  local header = frame:CreateTexture(nil, "BACKGROUND")
  header:SetPoint("TOPLEFT", 1, -1)
  header:SetPoint("TOPRIGHT", -1, -1)
  header:SetHeight(38)
  header:SetColorTexture(0.018, 0.019, 0.035, 1)
  local title = font(frame, 15, C.text, "OUTLINE")
  title:SetPoint("TOPLEFT", 16, -12)
  title:SetText("와니온 어시스트")
  local close = button(frame, "닫기", 54, function() frame:Hide() end)
  close:SetSize(54, 26)
  close:SetPoint("TOPRIGHT", -7, -7)

  local content = CreateFrame("Frame", nil, frame)
  content:SetPoint("TOPLEFT", 16, -72)
  content:SetPoint("BOTTOMRIGHT", -16, 58)

  local tabs = {
    { key = "invite", text = "1. 초대" },
    { key = "raid", text = "2. 파티 배치" },
    { key = "snapshot", text = "3. 스냅샷" },
  }
  local previous
  self.tabButtons = {}
  for i = 1, #tabs do
    local tab = tabs[i]
    local control = button(frame, tab.text, 98, function() WA.UI:SelectTab(tab.key) end)
    if previous then control:SetPoint("LEFT", previous, "RIGHT", 5, 0)
    else control:SetPoint("TOPLEFT", 18, -42) end
    self.tabButtons[tab.key] = control
    previous = control
  end

  local invite = self:CreateCodePanel(content, "invite", "WANION1 초대 코드를 붙여넣고 버튼을 누르세요.")
  self.panels.invite = invite
  local inviteStart = button(invite, "순차 초대 시작", 130, function()
    WA.Controller:RunCode(WA.UI:GetInput("invite"), "INV")
  end)
  inviteStart:SetPoint("BOTTOMLEFT", 12, 8)
  local inviteCancel = button(invite, "취소", 80, function() WA.InviteQueue:Stop("초대 큐를 취소했습니다.", false) end)
  inviteCancel:SetPoint("LEFT", inviteStart, "RIGHT", 8, 0)
  local inviteRetry = button(invite, "미확인 다시 초대", 130, function()
    WA.InviteQueue:RetryFailed()
  end)
  inviteRetry:SetPoint("LEFT", inviteCancel, "RIGHT", 8, 0)
  local invitePreview = button(invite, "명단 점검", 100, function()
    local message, err = WA.Controller:PreviewInvite(WA.UI:GetInput("invite"))
    WA.UI:SetStatus(message or err, err ~= nil)
  end)
  invitePreview:SetPoint("LEFT", inviteRetry, "RIGHT", 8, 0)

  local raid = self:CreateCodePanel(content, "raid", "WANION1 파티 배치 코드를 붙여넣으세요. 실행 중 매 단계 명단을 다시 확인합니다.")
  self.panels.raid = raid
  local preview = button(raid, "계획 확인", 100, function()
    local message, err = WA.Controller:PreviewSort(WA.UI:GetInput("raid"))
    WA.UI:SetStatus(message or err, err ~= nil)
  end)
  preview:SetPoint("BOTTOMLEFT", 12, 8)
  local raidStart = button(raid, "배치 시작", 100, function()
    WA.Controller:RunCode(WA.UI:GetInput("raid"), "SORT")
  end)
  raidStart:SetPoint("LEFT", preview, "RIGHT", 8, 0)
  local raidCancel = button(raid, "취소", 80, function() WA.RaidExecutor:Stop("파티 배치를 취소했습니다.", false) end)
  raidCancel:SetPoint("LEFT", raidStart, "RIGHT", 8, 0)

  local snapshotPanel = self:CreateCodePanel(content, "snapshot", "현재 파티/공격대 명단을 WANIONSNAP1 코드로 생성합니다.")
  self.panels.snapshot = snapshotPanel
  local snapshotButton = button(snapshotPanel, "스냅샷 생성", 120, function()
    local code, err = WA.Controller:Snapshot()
    if code then
      WA.UI:SetInput("snapshot", code)
      WA.UI:SetStatus("스냅샷 코드를 생성했습니다. Ctrl+C로 복사하세요.", false)
    else
      WA.UI:SetStatus(err, true)
    end
  end)
  snapshotButton:SetPoint("BOTTOMLEFT", 12, 8)

  local diagnosticPanel = self:CreateCodePanel(content, "diagnostics", "오류 신고 시 아래 진단 내용을 함께 전달하세요. 붙여넣은 원문 코드는 기록하지 않습니다.")
  self.panels.diagnostics = diagnosticPanel
  local refresh = button(diagnosticPanel, "진단 새로고침", 130, function()
    WA.UI:SetInput("diagnostics", WA.Diagnostics:Report())
  end)
  refresh:SetPoint("BOTTOMLEFT", 12, 8)

  self.status = font(frame, 11, C.sub)
  self.status:SetPoint("BOTTOMLEFT", 22, 24)
  self.status:SetPoint("BOTTOMRIGHT", -22, 24)
  self.status:SetJustifyH("LEFT")
  self.status:SetText("|cff8a70ff탭을 선택해 작업을 시작하세요.|r")
  WA:On("ACTION_STATUS", function(message, isError) WA.UI:SetStatus(message, isError) end)
  self:SelectTab("invite")
  self:BuildMinimapButton()
end

function WA.UI:BuildMinimapButton()
  local minimapButton = CreateFrame("Button", "WanionAssistMinimapButton", Minimap)
  minimapButton:SetSize(34, 34)
  minimapButton:SetFrameStrata("MEDIUM")
  minimapButton:RegisterForClicks("LeftButtonUp")
  minimapButton:RegisterForDrag("LeftButton")

  local circleMask = minimapButton:CreateMaskTexture(nil, "BACKGROUND")
  circleMask:SetTexture("Interface\\CharacterFrame\\TempPortraitAlphaMask", "CLAMPTOBLACKADDITIVE", "CLAMPTOBLACKADDITIVE")
  circleMask:SetAllPoints(minimapButton)

  local rim = minimapButton:CreateTexture(nil, "BACKGROUND", nil, -2)
  rim:SetTexture("Interface\\Buttons\\WHITE8X8")
  rim:SetVertexColor(C.violet[1], C.violet[2], C.violet[3], 0.95)
  rim:SetAllPoints(minimapButton)
  rim:AddMaskTexture(circleMask)

  local disk = minimapButton:CreateTexture(nil, "BACKGROUND", nil, -1)
  disk:SetTexture("Interface\\Buttons\\WHITE8X8")
  disk:SetVertexColor(C.bg[1], C.bg[2], C.bg[3], 0.98)
  disk:SetPoint("TOPLEFT", 2, -2)
  disk:SetPoint("BOTTOMRIGHT", -2, 2)
  disk:AddMaskTexture(circleMask)

  local icon = minimapButton:CreateTexture(nil, "ARTWORK")
  icon:SetTexture(WA.texture)
  icon:SetSize(21, 21)
  icon:SetPoint("CENTER", 0, 0)

  local function position()
    local radians = math.rad(WA.db.ui.minimapAngle)
    minimapButton:ClearAllPoints()
    minimapButton:SetPoint("CENTER", Minimap, "CENTER", 80 * math.cos(radians), 80 * math.sin(radians))
  end
  position()
  minimapButton:SetScript("OnDragStart", function(self)
    self:SetScript("OnUpdate", function()
      local x, y = Minimap:GetCenter()
      local cursorX, cursorY = GetCursorPosition()
      local scale = Minimap:GetEffectiveScale()
      WA.db.ui.minimapAngle = math.deg(math.atan2(cursorY / scale - y, cursorX / scale - x))
      position()
    end)
  end)
  minimapButton:SetScript("OnDragStop", function(self) self:SetScript("OnUpdate", nil) end)
  minimapButton:SetScript("OnClick", function() WA.UI:Toggle() end)
  minimapButton:SetScript("OnEnter", function(self)
    disk:SetVertexColor(C.surfaceHover[1], C.surfaceHover[2], C.surfaceHover[3], 1)
    rim:SetVertexColor(C.violet[1], C.violet[2], C.violet[3], 1)
    icon:SetSize(22, 22)
    GameTooltip:SetOwner(self, "ANCHOR_LEFT")
    GameTooltip:AddLine("와니온 어시스트")
    GameTooltip:AddLine("클릭: 창 열기/닫기", 0.7, 0.7, 0.7)
    GameTooltip:Show()
  end)
  minimapButton:SetScript("OnLeave", function()
    disk:SetVertexColor(C.bg[1], C.bg[2], C.bg[3], 0.98)
    rim:SetVertexColor(C.violet[1], C.violet[2], C.violet[3], 0.95)
    icon:SetSize(21, 21)
    GameTooltip:Hide()
  end)
end
