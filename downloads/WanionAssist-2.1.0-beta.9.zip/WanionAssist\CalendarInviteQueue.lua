local _, WA = ...

WA.CalendarInviteQueue = {
  state = "idle",
  pending = {},
  completed = 0,
  skipped = 0,
  failed = {},
}

local READY_POLL_SECONDS = 0.5
local ACTION_TIMEOUT_SECONDS = 20

local function cancelTimer(queue)
  if queue.timer and queue.timer.Cancel then queue.timer:Cancel() end
  queue.timer = nil
end

local function now()
  return GetTime and GetTime() or 0
end

local function canSendInvite()
  if not C_Calendar or type(C_Calendar.EventInvite) ~= "function" then return false end
  if not C_Calendar.CanSendInvite then return true end
  local ok, canSend = pcall(C_Calendar.CanSendInvite)
  return ok and canSend == true
end

local function calendarInviteKeys()
  local keys = {}
  if not C_Calendar or type(C_Calendar.EventGetNumInvites) ~= "function"
    or type(C_Calendar.EventGetInvite) ~= "function" then
    return keys, false
  end
  local countOk, count = pcall(C_Calendar.EventGetNumInvites)
  if not countOk or type(count) ~= "number" then return keys, false end
  for index = 1, count do
    local inviteOk, invite = pcall(C_Calendar.EventGetInvite, index)
    local name = inviteOk and type(invite) == "table" and invite.name or nil
    if name and WA.Identity and WA.Identity.FromText then
      local identity = WA.Identity:FromText(name)
      if identity then keys[identity.key] = true end
    end
  end
  return keys, true
end

local function scheduleReadyCheck(queue)
  cancelTimer(queue)
  if not C_Timer or type(C_Timer.NewTimer) ~= "function" then return end
  queue.timer = C_Timer.NewTimer(READY_POLL_SECONDS, function()
    WA.CalendarInviteQueue:OnReady()
  end)
end

function WA.CalendarInviteQueue:Notify(message, isError)
  WA.Diagnostics:Log(isError and "ERROR" or "INFO", "CALINV", message)
  WA:Emit("CALENDAR_INVITE_STATUS", message, isError)
  WA:Emit("ACTION_STATUS", message, isError)
end

function WA.CalendarInviteQueue:Stop(message, isError)
  cancelTimer(self)
  self.current = nil
  self.waitStartedAt = nil
  self.state = isError and "error" or "idle"
  if message then self:Notify(message, isError) end
end

function WA.CalendarInviteQueue:Start(attendees)
  if InCombatLockdown and InCombatLockdown() then
    return self:Notify("전투 중에는 달력 초대를 시작할 수 없습니다.", true)
  end
  if not C_Calendar or type(C_Calendar.EventInvite) ~= "function" then
    return self:Notify("현재 WoW 클라이언트에서 달력 초대 API를 사용할 수 없습니다.", true)
  end
  if not canSendInvite() then
    return self:Notify("먼저 WoW 기본 달력에서 일정을 저장한 뒤, 저장된 일정을 다시 열어 주세요.", true)
  end

  self:Stop()
  self.pending, self.failed = {}, {}
  self.completed, self.skipped = 0, 0
  local player = WA.Identity:FromUnit("player")
  local existingInvites = calendarInviteKeys()
  local seen = {}
  for i = 1, #(attendees or {}) do
    local identity = attendees[i]
    if identity and not seen[identity.key] then
      seen[identity.key] = true
      if (player and identity.key == player.key) or existingInvites[identity.key] then
        self.skipped = self.skipped + 1
      else
        self.pending[#self.pending + 1] = identity
      end
    end
  end

  if #self.pending == 0 then
    return self:Notify("초대할 확정 인원이 없습니다.", false)
  end
  self.state = "running"
  self:Notify(("달력 초대 시작: %d명 · 본인/중복 제외 %d명"):format(#self.pending, self.skipped), false)
  self:Advance()
end

function WA.CalendarInviteQueue:Advance()
  if self.state ~= "running" or self.current then return end
  if #self.pending == 0 then
    return self:Stop(("달력 초대 완료: 성공 %d명 · 실패 %d명 · 제외 %d명"):format(
      self.completed, #self.failed, self.skipped
    ), #self.failed > 0)
  end
  if InCombatLockdown and InCombatLockdown() then
    self.state = "paused-combat"
    return self:Notify("전투가 끝날 때까지 달력 초대를 잠시 멈춥니다.", false)
  end

  -- The calendar server can stay busy for several seconds after an invite.
  -- Busy is a transient state here; it must not abort the remaining roster.
  if not canSendInvite() then
    self.waitStartedAt = self.waitStartedAt or now()
    if now() - self.waitStartedAt >= ACTION_TIMEOUT_SECONDS then
      return self:Stop("달력 서버가 응답하지 않습니다. 저장된 일정을 다시 연 뒤 재시도해 주세요.", true)
    end
    scheduleReadyCheck(self)
    return
  end

  self.waitStartedAt = nil
  local requested = table.remove(self.pending, 1)
  self.current = requested
  local ok, err = pcall(C_Calendar.EventInvite, requested.fullName)
  if not ok then
    self.failed[#self.failed + 1] = { identity = requested, reason = tostring(err) }
    self.current = nil
    self:Notify("달력 초대 요청 실패: " .. requested.fullName .. " · " .. tostring(err), true)
    return self:Advance()
  end

  self.waitStartedAt = now()
  self:Notify(("달력 초대 요청 %d/%d: %s"):format(
    self.completed + #self.failed + 1,
    self.completed + #self.failed + #self.pending + 1,
    requested.fullName
  ), false)
  -- CALENDAR_ACTION_PENDING(false) is primary. Polling covers UI states where
  -- Blizzard does not emit it for every individual invite.
  if self.current == requested then scheduleReadyCheck(self) end
end

function WA.CalendarInviteQueue:OnReady()
  cancelTimer(self)
  if self.state ~= "running" then return end
  if not self.current then return self:Advance() end

  local inviteKeys, canVerifyInviteList = calendarInviteKeys()
  if canVerifyInviteList and inviteKeys[self.current.key] then
    self.completed = self.completed + 1
    self.current = nil
    self.waitStartedAt = nil
    return self:Advance()
  end

  if not canSendInvite() then
    if now() - (self.waitStartedAt or now()) >= ACTION_TIMEOUT_SECONDS then
      local failed = self.current
      self.failed[#self.failed + 1] = { identity = failed, reason = "calendar timeout" }
      self.current = nil
      self.waitStartedAt = nil
      self:Notify("달력 초대 확인 시간 초과: " .. failed.fullName, true)
      return self:Advance()
    end
    scheduleReadyCheck(self)
    return
  end


  -- 서버가 다시 준비됐더라도 현재 이름이 초대 목록에 나타나기 전에는
  -- 다음 사람으로 넘어가지 않는다. 빠른 연속 호출로 일부 초대가 유실되는 것을 막는다.
  if canVerifyInviteList then
    if now() - (self.waitStartedAt or now()) >= ACTION_TIMEOUT_SECONDS then
      local failed = self.current
      self.failed[#self.failed + 1] = { identity = failed, reason = "invite not confirmed" }
      self.current = nil
      self.waitStartedAt = nil
      self:Notify("달력 초대 확인 실패: " .. failed.fullName, true)
      return self:Advance()
    end
    scheduleReadyCheck(self)
    return
  end

  self.completed = self.completed + 1
  self.current = nil
  self.waitStartedAt = nil
  self:Advance()
end

function WA.CalendarInviteQueue:FailCurrent(reason, playerName)
  if self.state ~= "running" or not self.current then return end
  cancelTimer(self)
  local failed = self.current
  self.failed[#self.failed + 1] = {
    identity = failed,
    reason = tostring(reason or "calendar error"),
  }
  self.current = nil
  self.waitStartedAt = nil
  local detail = playerName and (" · " .. tostring(playerName)) or ""
  self:Notify("달력 초대 실패: " .. failed.fullName .. detail, true)
  self:Advance()
end

function WA.CalendarInviteQueue:RetryFailed()
  if #self.failed == 0 then
    return self:Notify("다시 시도할 달력 초대가 없습니다.", false)
  end
  local attendees = {}
  for i = 1, #self.failed do attendees[#attendees + 1] = self.failed[i].identity end
  self:Start(attendees)
end

function WA.CalendarInviteQueue:Initialize()
  local frame = CreateFrame("Frame")
  frame:RegisterEvent("CALENDAR_ACTION_PENDING")
  frame:RegisterEvent("CALENDAR_UPDATE_INVITE_LIST")
  frame:RegisterEvent("CALENDAR_UPDATE_ERROR")
  frame:RegisterEvent("CALENDAR_UPDATE_ERROR_WITH_PLAYER_NAME")
  frame:RegisterEvent("PLAYER_REGEN_ENABLED")
  frame:SetScript("OnEvent", function(_, eventName, first, second)
    if WA.CalendarInviteQueue.state == "running"
      and ((eventName == "CALENDAR_ACTION_PENDING" and first == false)
        or eventName == "CALENDAR_UPDATE_INVITE_LIST") then
      WA.CalendarInviteQueue:OnReady()
    elseif (eventName == "CALENDAR_UPDATE_ERROR" or eventName == "CALENDAR_UPDATE_ERROR_WITH_PLAYER_NAME")
      and WA.CalendarInviteQueue.state == "running" then
      WA.CalendarInviteQueue:FailCurrent(first, second)
    elseif eventName == "PLAYER_REGEN_ENABLED" and WA.CalendarInviteQueue.state == "paused-combat" then
      WA.CalendarInviteQueue.state = "running"
      WA.CalendarInviteQueue:Advance()
    end
  end)
  self.frame = frame
end
