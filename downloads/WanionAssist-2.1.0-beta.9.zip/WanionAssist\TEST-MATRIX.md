# WanionAssist 테스트 매트릭스

상태 표기: `PASS` 자동 검증 완료, `PENDING` Retail 12.0.7 실제 클라이언트 검증 필요.

| 영역 | 시나리오 | 기대 결과 | 상태 |
|---|---|---|---|
| 로드 | TOC 120100 및 모듈 순서 | 모든 Lua 파일이 존재하고 Core가 먼저 로드 | PASS |
| 호환 | ASCII INV 체크섬 | 웹 `bridge.js`와 `trla` 일치 | PASS |
| 호환 | UTF-8 SORT 체크섬 | 웹 `bridge.js`와 `p4h4` 일치 | PASS |
| 호환 | UTF-8 WANIONSNAP1 체크섬 | 웹 `bridge.js`와 `obwy` 일치 | PASS |
| 호환 | UTF-8 CAL 체크섬·URL 디코딩 | 웹과 Lua가 날짜·시간·한글·링크를 동일하게 해석 | PASS |
| Lua 5.1 | `goto`, `continue`, `::label::`, `//` 미사용 | 금지 문법 없음 | PASS |
| Lua 5.1 | 15개 모듈 전체 AST 파싱 | `luaparse` Lua 5.1 모드에서 구문 오류 없음 | PASS |
| 버전 | 한국 Retail 실행 파일·TOC | 설치 클라이언트 `12.1.0.69283`, TOC `120100` 일치 | PASS |
| 미니맵 | 로고와 배경 드로 레이어 | 로고가 보라색 배경 위 ARTWORK 레이어에 표시 | PASS |
| 프로토콜 | 빈 INV/SORT·잘린 URL 인코딩 | 실행 전에 명확한 한국어 오류로 거부 | PASS |
| 배치 계획 | 목표 파티가 찼고 미배정 인원이 존재 | 미배정 인원과 안전 교환 계획 생성 | PASS |
| 취소 | 전체 작업 취소 | 초대·배치·달력 초대 큐를 모두 중단 | PASS |
| 달력 정적 | 별도 패널·OnShow/OnHide 훅·위치 저장·우클릭 복귀 | 전용 UIParent 패널 토큰과 안전 훅·저장 필드 존재 | PASS |
| 달력 정적 | CalendarFrame 비침습·자동 저장 금지 | 기본 프레임 재배치/스크립트 교체와 AddEvent/생성 버튼 Click 호출 없음 | PASS |
| 식별 | 같은 이름·다른 서버 | `UnitFullName` 정규 키로 별도 캐릭터 처리 | PENDING |
| DB | 기존 저장값 `mmAngle`, `lastRaidId`, 설정 | schemaVersion 3으로 값 보존 이전 | PENDING |
| 달력 초대 | 저장한 일정에 확정 명단 초대 | 본인·중복 제외, CALENDAR_ACTION_PENDING 순차 처리 | PENDING |
| 운영 점검 | INV 명단과 현재 그룹 비교 | 합류·미합류·명단 외 인원 수와 미합류 이름 표시 | PENDING |
| 귓속말 초대 | 운영진이 선택적으로 활성화 | 정확한 키워드·10초 중복 방지·전투/권한 보호 | PENDING |
| 초대 | 미그룹 상태에서 3명 초대 | 한 명씩 요청, 합류/시간초과 후 다음 요청 | PENDING |
| 초대 | 초대 중 무관한 명단 이벤트 | 현재 대상 합류 전에는 다음 요청 안 함 | PENDING |
| 초대 | 합류 미확인 대상 다시 시도 | 다른 대상은 제외하고 미확인 대상만 새 큐로 실행 | PENDING |
| 초대 | 전투 진입/종료 | 큐 일시 정지 후 재개 | PENDING |
| 초대 | 도중 권한 상실 | 오류 표시 후 안전 중단 | PENDING |
| 배치 | 목표 파티에 빈자리 | SetRaidSubgroup 한 단계 실행 후 재스냅샷 | PENDING |
| 배치 | 목표 파티가 가득 참 | 안전한 잘못 배치된 대상과 SwapRaidSubgroup | PENDING |
| 배치 | 목표 파티 6명 지정 | API 호출 전 계획 오류 | PENDING |
| 배치 | 이동 결과 이벤트 없음 | 타임아웃 후 오류 중단 | PENDING |
| 배치 | 전투 진입/종료 | 실행 일시 정지 후 최신 명단으로 재계획 | PENDING |
| 달력 | CAL 미리보기 | 날짜·시간·제목·설명 길이·링크 포함 여부 표시 | PENDING |
| 달력 | 기본 작성 화면 열기 | 후보 내용 자동 입력, 사용자가 생성 버튼을 눌러야만 저장 | PENDING |
| 달력 | 과거/범위 밖 날짜·API/UI 부재 | 한국어 오류를 표시하고 자동 저장하지 않음 | PENDING |
| 달력 | 기본 달력 열기/닫기 | 열릴 때만 오른쪽에 별도 패널 표시, 닫히면 숨김 | PENDING |
| 달력 | 패널 이동 후 재접속·UI 배율/해상도 변경 | 저장 위치 복원 및 화면 밖 좌표 보정 | PENDING |
| 달력 | 패널 빈 영역 우클릭·오른쪽 공간 부족 | 저장 위치 삭제 후 오른쪽 우선, 부족하면 달력을 덮지 않고 왼쪽으로 복귀 | PENDING |
| 달력 | 전투 중 최초 로드·달력 프레임 미존재 | 오류 표시, CalendarFrame 무변경, 전투 종료 후 안전 재시도 | PENDING |
| UI | 미니맵 버튼과 메인 4개 탭 | 초대/배치/스냅샷/진단 흐름과 달력 전용 패널이 분리됨 | PENDING |
| Slash | open/invite/sort/snap/calendar/diag/cancel | 버튼 기능의 보조 경로로 동작 | PENDING |
| 진단 | 보고서 새로고침 | 원본 WANION 코드 없이 상태·revision·최근 오류 표시 | PENDING |

자동 검증 명령:

```powershell
node .\tests\static-check.mjs
```
