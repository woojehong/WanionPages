local _, WA = ...

WA.Slash = {}

function WA.Slash:Initialize()
  SLASH_WANIONASSIST1 = "/wanion"
  SLASH_WANIONASSIST2 = "/wno"
  SLASH_WANIONASSIST3 = "/ㅈ무ㅑㅐㅜ"
  SLASH_WANIONASSIST4 = "/주ㅐ"
  SLASH_WANIONASSIST5 = "/wan"
  SlashCmdList.WANIONASSIST = function(message)
    message = WA.Trim(message)
    local command, remainder = message:match("^(%S+)%s*(.-)$")
    command = string.lower(command or "")
    if command == "" or command == "open" then
      WA.UI:Toggle()
    elseif command == "invite" or command == "i" then
      WA.UI:SelectTab("invite")
      WA.UI.frame:Show()
      if remainder ~= "" then WA.UI:SetInput("invite", remainder) end
      WA.Controller:RunCode(WA.UI:GetInput("invite"), "INV")
    elseif command == "sort" or command == "p" then
      WA.UI:SelectTab("raid")
      WA.UI.frame:Show()
      if remainder ~= "" then WA.UI:SetInput("raid", remainder) end
      WA.Controller:RunCode(WA.UI:GetInput("raid"), "SORT")
    elseif command == "snap" or command == "s" then
      WA.UI:SelectTab("snapshot")
      WA.UI.frame:Show()
      local code, err = WA.Controller:Snapshot()
      if code then WA.UI:SetInput("snapshot", code) else WA.UI:SetStatus(err, true) end
    elseif command == "calendar" or command == "cal" or command == "c" then
      local opened, status = WA.Calendar:OpenSidePanel(remainder)
      WA:Emit("ACTION_STATUS", status, not opened)
    elseif command == "diag" or command == "d" then
      WA.UI:SelectTab("diagnostics")
      WA.UI.frame:Show()
      WA.UI:SetInput("diagnostics", WA.Diagnostics:Report())
    elseif command == "cancel" or command == "x" then
      WA.Controller:Cancel()
    elseif command == "retry" then
      WA.InviteQueue:RetryFailed()
    else
      WA.UI:SetStatus("명령: /wan, /wan i, /wan p, /wan s, /wan c, /wan d, /wan x", true)
      WA.UI.frame:Show()
    end
  end
  print("|cff8a70ff와니온 어시스트 애드온|r 로드 완료 — 미니맵 버튼 또는 /wan")
end
