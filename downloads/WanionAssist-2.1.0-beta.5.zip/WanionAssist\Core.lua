local addonName, WA = ...

WA.name = addonName
WA.version = "2.1.0-beta.5"
WA.schemaVersion = 3
WA.protocolVersion = "WANION1"
WA.snapshotVersion = "WANIONSNAP1"
WA.texture = "Interface\\AddOns\\WanionAssist\\Media\\icon-64"
WA.callbacks = {}

function WA.Trim(value)
  value = tostring(value or "")
  if strtrim then return strtrim(value) end
  return (value:gsub("^%s+", ""):gsub("%s+$", ""))
end

function WA:On(eventName, callback)
  if type(callback) ~= "function" then return end
  self.callbacks[eventName] = self.callbacks[eventName] or {}
  table.insert(self.callbacks[eventName], callback)
end

function WA:Emit(eventName, ...)
  local callbacks = self.callbacks[eventName]
  if not callbacks then return end
  for i = 1, #callbacks do
    local ok, err = pcall(callbacks[i], ...)
    if not ok and self.Diagnostics then
      self.Diagnostics:Log("ERROR", "CALLBACK", tostring(err))
    end
  end
end

function WA.Now()
  if GetTime then return GetTime() end
  return 0
end

function WA.IsOperator()
  if not IsInGroup or not IsInGroup() then return true end
  return (UnitIsGroupLeader and UnitIsGroupLeader("player"))
    or (IsInRaid and IsInRaid() and UnitIsGroupAssistant and UnitIsGroupAssistant("player"))
end
