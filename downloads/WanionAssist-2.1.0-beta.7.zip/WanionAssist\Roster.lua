local _, WA = ...

WA.Roster = { revision = 0 }

local function add(snapshot, unit, raidIndex, subgroup, classFile)
  local identity = WA.Identity:FromUnit(unit)
  if not identity then return end
  local entry = {
    unit = unit,
    raidIndex = raidIndex,
    subgroup = subgroup or 1,
    identity = identity,
    key = identity.key,
    fullName = identity.fullName,
    classFile = classFile,
  }
  snapshot.byKey[entry.key] = entry
  table.insert(snapshot.members, entry)
end

function WA.Roster:Capture(reason, emitEvent)
  self.revision = self.revision + 1
  local snapshot = {
    revision = self.revision,
    reason = reason or "manual",
    capturedAt = WA.Now(),
    isRaid = IsInRaid and IsInRaid() or false,
    isGroup = IsInGroup and IsInGroup() or false,
    members = {},
    byKey = {},
  }

  if snapshot.isRaid then
    local count = GetNumGroupMembers and GetNumGroupMembers() or 0
    for i = 1, count do
      local _, _, subgroup, _, _, classFile = GetRaidRosterInfo(i)
      add(snapshot, "raid" .. i, i, subgroup, classFile)
    end
  else
    add(snapshot, "player", nil, 1)
    if snapshot.isGroup then
      local count = GetNumSubgroupMembers and GetNumSubgroupMembers() or 0
      for i = 1, count do add(snapshot, "party" .. i, nil, 1) end
    end
  end

  local fingerprintParts = {}
  for i = 1, #snapshot.members do
    local member = snapshot.members[i]
    fingerprintParts[#fingerprintParts + 1] = member.key .. ":" .. tostring(member.subgroup)
  end
  table.sort(fingerprintParts)
  snapshot.fingerprint = table.concat(fingerprintParts, "|")
  snapshot.count = #snapshot.members
  self.current = snapshot
  if emitEvent then WA:Emit("ROSTER_SNAPSHOT", snapshot) end
  return snapshot
end

function WA.Roster:Initialize()
  local frame = CreateFrame("Frame")
  frame:RegisterEvent("GROUP_ROSTER_UPDATE")
  frame:RegisterEvent("PLAYER_ENTERING_WORLD")
  frame:SetScript("OnEvent", function(_, eventName)
    WA.Roster:Capture(eventName, true)
  end)
  self.frame = frame
end
