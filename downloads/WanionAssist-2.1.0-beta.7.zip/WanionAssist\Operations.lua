local _, WA = ...

WA.Operations = {}

function WA.Operations:Analyze(entries)
  local snapshot = WA.Roster:Capture("operations-preview")
  local present, missing, extra = {}, {}, {}
  local expected = {}
  for i = 1, #(entries or {}) do
    local entry = entries[i]
    expected[entry.identity.key] = entry
    if snapshot.byKey[entry.identity.key] then present[#present + 1] = entry
    else missing[#missing + 1] = entry end
  end
  for key, member in pairs(snapshot.byKey or {}) do
    if not expected[key] then extra[#extra + 1] = member end
  end
  table.sort(missing, function(a, b) return a.identity.fullName < b.identity.fullName end)
  table.sort(extra, function(a, b) return a.fullName < b.fullName end)
  return { planned = #(entries or {}), present = present, missing = missing, extra = extra }
end

function WA.Operations:PreviewInvite(raw)
  local parsed, err = WA.Protocol:Parse(raw, "INV")
  if not parsed then return nil, err end
  local result = self:Analyze(parsed.entries)
  local names = {}
  for i = 1, math.min(5, #result.missing) do names[#names + 1] = result.missing[i].identity.fullName end
  local suffix = #names > 0 and (" · 미합류: " .. table.concat(names, ", ")) or ""
  if #result.missing > 5 then suffix = suffix .. (" 외 %d명"):format(#result.missing - 5) end
  return ("계획 %d명 · 합류 %d명 · 미합류 %d명 · 명단 외 %d명%s"):format(
    result.planned, #result.present, #result.missing, #result.extra, suffix)
end
