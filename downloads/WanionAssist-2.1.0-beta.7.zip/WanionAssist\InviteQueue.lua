local _, WA = ...

WA.InviteQueue = {
  state = "idle",
  pending = {},
  completed = 0,
  timedOut = 0,
  skipped = 0,
  failedEntries = {},
}

local function cancelTimer(queue)
  if queue.timer and queue.timer.Cancel then queue.timer:Cancel() end
  queue.timer = nil
end

function WA.InviteQueue:Notify(message, isError)
  WA.Diagnostics:Log(isError and "ERROR" or "INFO", "INVITE", message)
  WA:Emit("ACTION_STATUS", message, isError)
end

function WA.InviteQueue:Stop(message, isError)
  cancelTimer(self)
  self.current = nil
  self.pending = {}
  self.state = isError and "error" or "idle"
  if message then self:Notify(message, isError) end
end

function WA.InviteQueue:Start(entries)
  self:Stop()
  local snapshot = WA.Roster:Capture("invite-start")
  local seen = {}
  self.completed, self.timedOut, self.skipped = 0, 0, 0
  self.failedEntries = {}
  for i = 1, #entries do
    local entry = entries[i]
    if snapshot.byKey[entry.identity.key] or seen[entry.identity.key] then
      self.skipped = self.skipped + 1
    else
      seen[entry.identity.key] = true
      self.pending[#self.pending + 1] = entry
    end
  end
  self.state = "running"
  self:Notify(("초대 큐 시작: 대기 %d명, 제외 %d명"):format(#self.pending, self.skipped))
  self:Advance()
end

function WA.InviteQueue:RetryFailed()
  if self.state == "running" or self.state == "paused-combat" then
    return self:Notify("진행 중인 초대 큐를 먼저 완료하거나 취소하세요.", true)
  end
  if #self.failedEntries == 0 then
    return self:Notify("다시 시도할 합류 미확인 대상이 없습니다.", false)
  end
  local retry = self.failedEntries
  self.failedEntries = {}
  self:Start(retry)
end

function WA.InviteQueue:Advance()
  if self.state ~= "running" or self.current then return end
  local snapshot = WA.Roster:Capture("invite-step")
  while self.pending[1] and snapshot.byKey[self.pending[1].identity.key] do
    table.remove(self.pending, 1)
    self.skipped = self.skipped + 1
  end
  if #self.pending == 0 then
    local summary = ("초대 완료: 합류 %d명, 시간초과 %d명, 제외 %d명"):format(
      self.completed, self.timedOut, self.skipped)
    return self:Stop(summary, false)
  end
  if InCombatLockdown and InCombatLockdown() then
    self.state = "paused-combat"
    return self:Notify("전투가 끝날 때까지 초대 큐를 일시 정지합니다.", false)
  end
  if not WA.IsOperator() then return self:Stop("초대 권한이 없어 큐를 중단했습니다.", true) end
  if C_PartyInfo and type(C_PartyInfo.CanInvite) == "function" and not C_PartyInfo.CanInvite() then
    return self:Stop("현재 파티 상태에서는 초대할 수 없습니다.", true)
  end
  if C_PartyInfo and type(C_PartyInfo.IsPartyFull) == "function" and C_PartyInfo.IsPartyFull() then
    return self:Stop("파티 또는 공격대가 가득 차 초대를 중단했습니다.", true)
  end
  if not C_PartyInfo or type(C_PartyInfo.InviteUnit) ~= "function" then
    return self:Stop("C_PartyInfo.InviteUnit API를 사용할 수 없습니다.", true)
  end

  self.current = table.remove(self.pending, 1)
  local ok, err = pcall(C_PartyInfo.InviteUnit, self.current.identity.fullName)
  if not ok then
    local failedName = self.current.identity.fullName
    self.current = nil
    return self:Stop("초대 요청 실패 (" .. failedName .. "): " .. tostring(err), true)
  end
  self:Notify("초대 요청: " .. self.current.identity.fullName)
  local timeout = WA.db.settings.inviteTimeout
  self.timer = C_Timer.NewTimer(timeout, function()
    WA.InviteQueue:OnTimeout()
  end)
end

function WA.InviteQueue:OnRoster(snapshot)
  if self.state ~= "running" or not self.current then return end
  if snapshot.byKey[self.current.identity.key] then
    cancelTimer(self)
    self.completed = self.completed + 1
    self.current = nil
    self:Advance()
  end
end

function WA.InviteQueue:OnTimeout()
  self.timer = nil
  if self.state ~= "running" or not self.current then return end
  local snapshot = WA.Roster:Capture("invite-timeout")
  if snapshot.byKey[self.current.identity.key] then
    self.completed = self.completed + 1
  else
    self.timedOut = self.timedOut + 1
    self.failedEntries[#self.failedEntries + 1] = self.current
    self:Notify("합류 확인 시간초과: " .. self.current.identity.fullName, false)
  end
  self.current = nil
  self:Advance()
end

function WA.InviteQueue:Initialize()
  WA:On("ROSTER_SNAPSHOT", function(snapshot) WA.InviteQueue:OnRoster(snapshot) end)
  local frame = CreateFrame("Frame")
  frame:RegisterEvent("PLAYER_REGEN_ENABLED")
  frame:SetScript("OnEvent", function()
    if WA.InviteQueue.state == "paused-combat" then
      WA.InviteQueue.state = "running"
      WA.InviteQueue:Advance()
    end
  end)
  self.frame = frame
end
