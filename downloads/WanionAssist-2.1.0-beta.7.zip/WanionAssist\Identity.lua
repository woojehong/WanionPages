local _, WA = ...

WA.Identity = {}

local function normalizedRealm(realm)
  realm = WA.Trim(realm)
  if realm == "" then
    if GetNormalizedRealmName then realm = GetNormalizedRealmName() or "" end
    if realm == "" and GetRealmName then realm = GetRealmName() or "" end
  end
  if NormalizeRealmName then
    local normalized = NormalizeRealmName(realm)
    if normalized and normalized ~= "" then realm = normalized end
  end
  return realm:gsub("%s+", "")
end

local function build(name, realm)
  name = WA.Trim(name):gsub("%s+", "")
  realm = normalizedRealm(realm)
  if name == "" or realm == "" then return nil, "캐릭터 이름 또는 서버가 비어 있습니다." end
  local fullName = name .. "-" .. realm
  return {
    name = name,
    realm = realm,
    fullName = fullName,
    key = string.lower(fullName),
  }
end

function WA.Identity:FromUnit(unit)
  if not UnitFullName then return nil, "UnitFullName API를 사용할 수 없습니다." end
  local name, realm = UnitFullName(unit)
  if not name then return nil, "유닛 이름을 확인할 수 없습니다: " .. tostring(unit) end
  return build(name, realm)
end

function WA.Identity:FromText(text)
  text = WA.Trim(text)
  if text == "" then return nil, "캐릭터 이름이 비어 있습니다." end
  local split = text:find("-", 1, true)
  if split then return build(text:sub(1, split - 1), text:sub(split + 1)) end
  return build(text, nil)
end
