local _, WA = ...

WA.Protocol = {}

local B36 = "0123456789abcdefghijklmnopqrstuvwxyz"
local ROLE = { T = "tank", H = "heal", D = "dps", G = "guest" }

local function toBase36(number)
  if number == 0 then return "0" end
  local result = ""
  while number > 0 do
    local remainder = number % 36
    result = B36:sub(remainder + 1, remainder + 1) .. result
    number = math.floor(number / 36)
  end
  return result
end

function WA.Protocol:Checksum(payload)
  local sum = 0
  for i = 1, #payload do
    sum = (sum * 31 + payload:byte(i)) % 1679615
  end
  local encoded = toBase36(sum)
  return ("0"):rep(math.max(0, 4 - #encoded)) .. encoded
end

local function split(value, separator)
  local result = {}
  local startAt = 1
  while true do
    local found = value:find(separator, startAt, true)
    if not found then
      result[#result + 1] = value:sub(startAt)
      return result
    end
    result[#result + 1] = value:sub(startAt, found - 1)
    startAt = found + #separator
  end
end

local function decodeEnvelope(raw)
  raw = WA.Trim(raw)
  local lastSeparator
  for i = #raw, 1, -1 do
    if raw:sub(i, i) == ";" then lastSeparator = i break end
  end
  if not lastSeparator then return nil, "WANION 코드 형식이 아닙니다." end
  local payload = raw:sub(1, lastSeparator - 1)
  if WA.Protocol:Checksum(payload) ~= raw:sub(lastSeparator + 1) then
    return nil, "체크섬이 일치하지 않습니다. 코드를 다시 복사하세요."
  end
  local fields = split(payload, ";")
  if fields[1] ~= WA.protocolVersion then return nil, "지원하지 않는 WANION 코드 버전입니다." end
  if fields[2] ~= "INV" and fields[2] ~= "SORT" and fields[2] ~= "CAL" then
    return nil, "INV, SORT 또는 CAL 코드가 아닙니다."
  end
  local validFields = fields[2] == "CAL" and (#fields == 8 or #fields == 9) or #fields == 4
  if not validFields then return nil, "코드 필드 수가 올바르지 않습니다." end
  return { mode = fields[2], raidId = fields[3], list = fields[4], fields = fields }
end

function WA.Protocol:Parse(raw, expectedMode)
  local envelope, err = decodeEnvelope(raw)
  if not envelope then return nil, err end
  if expectedMode and envelope.mode ~= expectedMode then return nil, expectedMode .. " 코드가 아닙니다." end
  if envelope.mode == "CAL" then return nil, "CAL 코드는 달력 탭에서 사용하세요." end
  local entries = {}
  local tokens = split(envelope.list, ",")
  for i = 1, #tokens do
    if tokens[i] ~= "" then
      local fields = split(tokens[i], ":")
      local identity, identityErr = WA.Identity:FromText(fields[1])
      if not identity then return nil, identityErr end
      if envelope.mode == "INV" then
        local roleParts = split(fields[2] or "D", "+")
        local mainRole = (roleParts[1] or "D"):sub(1, 1)
        local party = tonumber(fields[3])
        if fields[3] and (not party or party < 1 or party > 8) then
          return nil, identity.fullName .. "의 파티 번호가 잘못되었습니다."
        end
        entries[#entries + 1] = {
          identity = identity,
          role = ROLE[mainRole] or "dps",
          party = party,
        }
      else
        local party = tonumber(fields[2])
        if not party or party < 1 or party > 8 then
          return nil, identity.fullName .. "의 파티 번호가 잘못되었습니다."
        end
        entries[#entries + 1] = { identity = identity, party = party }
      end
    end
  end
  if #entries == 0 then return nil, envelope.mode .. " 명단이 비어 있습니다." end
  envelope.entries = entries
  return envelope
end

local function decodeComponent(value)
  local index = 1
  while true do
    local marker = value:find("%", index, true)
    if not marker then break end
    local hex = value:sub(marker + 1, marker + 2)
    if #hex ~= 2 or not hex:match("^%x%x$") then return nil end
    index = marker + 3
  end
  return (value:gsub("%%(%x%x)", function(hex)
    return string.char(tonumber(hex, 16))
  end))
end

local function isLeapYear(year)
  return year % 400 == 0 or (year % 4 == 0 and year % 100 ~= 0)
end

local function validDate(year, month, day)
  if year < 2000 or year > 9999 or month < 1 or month > 12 or day < 1 then return false end
  local days = { 31, isLeapYear(year) and 29 or 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 }
  return day <= days[month]
end

function WA.Protocol:ParseCalendar(raw)
  local envelope, err = decodeEnvelope(raw)
  if not envelope then return nil, err end
  if envelope.mode ~= "CAL" then return nil, "CAL 코드가 아닙니다." end
  local fields = envelope.fields
  local year, month, day = fields[4]:match("^(%d%d%d%d)%-(%d%d)%-(%d%d)$")
  local hour, minute = fields[5]:match("^(%d%d):(%d%d)$")
  year, month, day = tonumber(year), tonumber(month), tonumber(day)
  hour, minute = tonumber(hour), tonumber(minute)
  if not year or not hour or not validDate(year, month, day) or hour > 23 or minute > 59 then
    return nil, "CAL 코드의 날짜 또는 시간이 올바르지 않습니다."
  end
  local raidId = decodeComponent(fields[3])
  local title = decodeComponent(fields[6])
  local description = decodeComponent(fields[7])
  local link = decodeComponent(fields[8])
  local attendeeText = fields[9] and decodeComponent(fields[9]) or ""
  if not raidId or not title or not description or not link or attendeeText == nil then
    return nil, "CAL 코드의 텍스트 인코딩이 손상되었습니다."
  end
  if WA.Trim(title) == "" then return nil, "달력 일정 제목이 비어 있습니다." end
  local attendees, attendeeSeen = {}, {}
  local attendeeTokens = split(attendeeText, ",")
  for i = 1, #attendeeTokens do
    if WA.Trim(attendeeTokens[i]) ~= "" then
      local identity, identityErr = WA.Identity:FromText(attendeeTokens[i])
      if not identity then return nil, "달력 초대 명단: " .. tostring(identityErr) end
      if not attendeeSeen[identity.key] then
        attendeeSeen[identity.key] = true
        attendees[#attendees + 1] = identity
      end
    end
  end
  if #title > 255 then return nil, "CAL 코드의 일정 제목이 너무 깁니다." end
  if #description > 4096 then return nil, "CAL 코드의 일정 설명이 너무 깁니다." end
  return {
    mode = "CAL",
    raidId = raidId,
    year = year,
    month = month,
    day = day,
    hour = hour,
    minute = minute,
    title = title,
    description = description,
    link = link,
    attendees = attendees,
  }
end

function WA.Protocol:BuildSnapshot(raidId, snapshot)
  local names = {}
  for i = 1, #snapshot.members do names[#names + 1] = snapshot.members[i].fullName end
  local payload = WA.snapshotVersion .. ";" .. tostring(raidId or "snap") .. ";" .. table.concat(names, ",")
  return payload .. ";" .. self:Checksum(payload)
end

function WA.Protocol:BuildSort(raidId, snapshot, assignments)
  local entries = {}
  for i = 1, #snapshot.members do
    local member = snapshot.members[i]
    local party = tonumber(assignments and assignments[member.key])
    if party and party >= 1 and party <= 8 then
      entries[#entries + 1] = member.fullName .. ":" .. tostring(party)
    end
  end
  if #entries == 0 then return nil, "내보낼 파티 배치가 없습니다." end
  local payload = WA.protocolVersion .. ";SORT;" .. tostring(raidId or "ingame") .. ";" .. table.concat(entries, ",")
  return payload .. ";" .. self:Checksum(payload)
end
