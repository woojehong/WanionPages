local _, WA = ...

WA.RaidExecutor = { state = "idle", assignments = {} }

local function cancelTimer(executor)
  if executor.timer and executor.timer.Cancel then executor.timer:Cancel() end
  executor.timer = nil
end

local function validateCapacity(assignments)
  local counts = {}
  for _, group in pairs(assignments) do
    counts[group] = (counts[group] or 0) + 1
    if counts[group] > 5 then return false, tostring(group) .. "파티 배정이 5명을 초과합니다." end
  end
  return true
end

local function findSpareGroup(counts, excludedA, excludedB)
  for group = 1, 8 do
    if group ~= excludedA and group ~= excludedB and (counts[group] or 0) < 5 then
      return group
    end
  end
end

function WA.RaidExecutor:BuildPlan(snapshot, assignments)
  local valid, err = validateCapacity(assignments)
  if not valid then return nil, err end
  local simulated, counts, missing = {}, {}, {}
  for i = 1, #snapshot.members do
    local member = snapshot.members[i]
    simulated[member.key] = {
      key = member.key,
      fullName = member.fullName,
      raidIndex = member.raidIndex,
      subgroup = member.subgroup,
    }
    counts[member.subgroup] = (counts[member.subgroup] or 0) + 1
  end
  for key in pairs(assignments) do
    if not simulated[key] then missing[#missing + 1] = key end
  end

  local steps = {}
  local maximum = math.max(1, #snapshot.members * 3)
  for iteration = 1, maximum do
    local target
    for key, desired in pairs(assignments) do
      local member = simulated[key]
      if member and member.subgroup ~= desired then target = member break end
    end
    if not target then return { steps = steps, missing = missing }, nil end
    local desired = assignments[target.key]
    if (counts[desired] or 0) < 5 then
      steps[#steps + 1] = { kind = "MOVE", first = target, group = desired }
      counts[target.subgroup] = counts[target.subgroup] - 1
      counts[desired] = (counts[desired] or 0) + 1
      target.subgroup = desired
    else
      local candidate
      for _, member in pairs(simulated) do
        if member.subgroup == desired
          and assignments[member.key]
          and assignments[member.key] ~= desired then
          candidate = member
          if assignments[member.key] == target.subgroup then break end
        end
      end
      if not candidate then
        for _, member in pairs(simulated) do
          if member.subgroup == desired and not assignments[member.key] then
            candidate = member
            break
          end
        end
      end
      if not candidate then
        return nil, target.fullName .. "의 목표 파티가 가득 차 있어 안전한 교환 대상을 찾지 못했습니다."
      end
      if not assignments[candidate.key] or assignments[candidate.key] == target.subgroup then
        steps[#steps + 1] = { kind = "SWAP", first = target, second = candidate }
        local oldGroup = target.subgroup
        target.subgroup = candidate.subgroup
        candidate.subgroup = oldGroup
      else
        local spare = findSpareGroup(counts, desired, target.subgroup)
        if not spare then
          return nil, target.fullName .. "을 안전하게 배치할 임시 빈자리가 없습니다."
        end
        steps[#steps + 1] = { kind = "MOVE", first = candidate, group = spare }
        counts[candidate.subgroup] = counts[candidate.subgroup] - 1
        counts[spare] = (counts[spare] or 0) + 1
        candidate.subgroup = spare
      end
    end
  end
  return nil, "배치 계획이 안전 반복 한도를 초과했습니다."
end

function WA.RaidExecutor:Notify(message, isError)
  WA.Diagnostics:Log(isError and "ERROR" or "INFO", "RAID", message)
  WA:Emit("ACTION_STATUS", message, isError)
end

function WA.RaidExecutor:Stop(message, isError)
  cancelTimer(self)
  self.awaitingFingerprint = nil
  self.state = isError and "error" or "idle"
  if message then self:Notify(message, isError) end
end

function WA.RaidExecutor:Preview(entries)
  local assignments = {}
  for i = 1, #entries do assignments[entries[i].identity.key] = entries[i].party end
  local snapshot = WA.Roster:Capture("raid-preview")
  return self:BuildPlan(snapshot, assignments)
end

function WA.RaidExecutor:Start(entries)
  self:Stop()
  self.assignments = {}
  for i = 1, #entries do self.assignments[entries[i].identity.key] = entries[i].party end
  self.state = "running"
  self:Process()
end

function WA.RaidExecutor:Process()
  if self.state ~= "running" or self.awaitingFingerprint then return end
  local snapshot = WA.Roster:Capture("raid-step")
  if not snapshot.isRaid then return self:Stop("공격대 상태에서만 파티를 배치할 수 있습니다.", true) end
  if InCombatLockdown and InCombatLockdown() then
    self.state = "paused-combat"
    return self:Notify("전투가 끝날 때까지 파티 배치를 일시 정지합니다.", false)
  end
  if not WA.IsOperator() then return self:Stop("공대장 또는 부공대장 권한이 필요합니다.", true) end
  local plan, err = self:BuildPlan(snapshot, self.assignments)
  if not plan then return self:Stop(err, true) end
  if #plan.steps == 0 then
    return self:Stop(("파티 배치 완료 (명단에 없음 %d명)"):format(#plan.missing), false)
  end

  local step = plan.steps[1]
  local ok, callErr
  if step.kind == "MOVE" then
    if type(SetRaidSubgroup) ~= "function" then return self:Stop("SetRaidSubgroup API가 없습니다.", true) end
    ok, callErr = pcall(SetRaidSubgroup, step.first.raidIndex, step.group)
  else
    if type(SwapRaidSubgroup) ~= "function" then return self:Stop("SwapRaidSubgroup API가 없습니다.", true) end
    ok, callErr = pcall(SwapRaidSubgroup, step.first.raidIndex, step.second.raidIndex)
  end
  if not ok then return self:Stop("파티 이동 API 실패: " .. tostring(callErr), true) end
  if step.kind == "MOVE" then
    self:Notify(("%s → %d파티 요청"):format(step.first.fullName, step.group), false)
  else
    self:Notify(("%s ↔ %s 교환 요청"):format(step.first.fullName, step.second.fullName), false)
  end

  self.awaitingFingerprint = snapshot.fingerprint
  self.timer = C_Timer.NewTimer(WA.db.settings.raidStepTimeout, function()
    WA.RaidExecutor:OnTimeout()
  end)
end

function WA.RaidExecutor:OnRoster(snapshot)
  if self.state ~= "running" or not self.awaitingFingerprint then return end
  if snapshot.fingerprint ~= self.awaitingFingerprint then
    cancelTimer(self)
    self.awaitingFingerprint = nil
    self:Process()
  end
end

function WA.RaidExecutor:OnTimeout()
  self.timer = nil
  if self.state ~= "running" then return end
  local snapshot = WA.Roster:Capture("raid-timeout")
  if snapshot.fingerprint == self.awaitingFingerprint then
    return self:Stop("파티 이동 결과를 확인하지 못해 중단했습니다.", true)
  end
  self.awaitingFingerprint = nil
  self:Process()
end

function WA.RaidExecutor:Initialize()
  WA:On("ROSTER_SNAPSHOT", function(snapshot) WA.RaidExecutor:OnRoster(snapshot) end)
  local frame = CreateFrame("Frame")
  frame:RegisterEvent("PLAYER_REGEN_ENABLED")
  frame:SetScript("OnEvent", function()
    if WA.RaidExecutor.state == "paused-combat" then
      WA.RaidExecutor.state = "running"
      WA.RaidExecutor:Process()
    end
  end)
  self.frame = frame
end
