import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import luaparse from 'luaparse';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const toc = fs.readFileSync(path.join(root, 'WanionAssist.toc'), 'utf8');
const expectedModules = [
  'Core.lua',
  'Database.lua',
  'Identity.lua',
  'Roster.lua',
  'Protocol.lua',
  'Calendar.lua',
  'CalendarInviteQueue.lua',
  'Diagnostics.lua',
  'InviteQueue.lua',
  'RaidExecutor.lua',
  'Operations.lua',
  'Controller.lua',
  'UI.lua',
  'Slash.lua',
];

assert.match(toc, /^## Interface: 120007$/m);
assert.match(toc, /^## Version: 2\.1\.0-beta\.7$/m);
let previous = -1;
const tocLines = toc.split(/\r?\n/).map((line) => line.trim());
for (const moduleName of expectedModules) {
  const location = tocLines.indexOf(moduleName);
  assert.ok(location > previous, `${moduleName} must exist in TOC load order`);
  assert.ok(fs.existsSync(path.join(root, moduleName)), `${moduleName} is missing`);
  previous = location;
}

const sources = expectedModules.map((name) => fs.readFileSync(path.join(root, name), 'utf8'));
for (let index = 0; index < sources.length; index += 1) {
  const source = sources[index];
  assert.ok(!source.includes('\uFFFD'), `${expectedModules[index]} contains invalid UTF-8 replacement text`);
  assert.doesNotMatch(source, /\bgoto\b|::[A-Za-z_][A-Za-z0-9_]*::|\bcontinue\b|\/\/=/,
    `${expectedModules[index]} contains unsupported Lua syntax`);
  assert.doesNotThrow(
    () => luaparse.parse(source, { luaVersion: '5.1', comments: false, scope: true }),
    `${expectedModules[index]} must parse as Lua 5.1`
  );
}

const all = sources.join('\n');
for (const required of [
  'UnitFullName',
  'GROUP_ROSTER_UPDATE',
  'C_PartyInfo.InviteUnit',
  'SetRaidSubgroup',
  'SwapRaidSubgroup',
  'InCombatLockdown',
  'BuildRaidEditor',
  'AssignRaidEditorMember',
  'GetMouseFoci',
  'BuildSort',
  'schemaVersion',
  'WANION1',
  'WANIONSNAP1',
  'C_Calendar.CreatePlayerEvent',
  'C_Calendar.EventSetDate',
  'C_Calendar.EventSetTime',
  'C_Calendar.EventSetTitle',
  'C_Calendar.EventSetDescription',
  'CalendarFrame_ShowEventFrame',
  'C_Calendar.EventInvite',
  'CALENDAR_ACTION_PENDING',
]) {
  assert.ok(all.includes(required), `required implementation token missing: ${required}`);
}

function checksum(payload) {
  const bytes = new TextEncoder().encode(payload);
  let sum = 0;
  for (const byte of bytes) sum = (sum * 31 + byte) % 1679615;
  return sum.toString(36).padStart(4, '0');
}

assert.equal(checksum('WANION1;INV;raid-1;Alpha-Azshara:T:1'), 'trla');
assert.equal(checksum('WANION1;SORT;공대-7;두부킴-아즈샤라:1'), 'p4h4');
assert.equal(checksum('WANIONSNAP1;snap;두부킴-아즈샤라,빛나래-아즈샤라'), 'obwy');
const calendarPayload = 'WANION1;CAL;raid-7;2026-08-09;20:30;%EA%B3%B5%ED%97%88%20%EA%B3%B5%EB%8C%80;%EC%A4%80%EB%B9%84%EB%AC%BC%20%ED%99%95%EC%9D%B8;https%3A%2F%2Fwanion.website%2Fraid%2Fraid-7';
assert.equal(checksum(calendarPayload), 'nyjo');
const calendarAttendeePayload = `${calendarPayload};%ED%9B%84%EC%A0%9C-%EC%95%84%EC%A6%88%EC%83%A4%EB%9D%BC%2C%EB%A7%88%EA%B3%A0-%EC%95%84%EC%A6%88%EC%83%A4%EB%9D%BC`;
assert.equal(checksum(calendarAttendeePayload), '8hxr');

const protocol = fs.readFileSync(path.join(root, 'Protocol.lua'), 'utf8');
assert.match(protocol, /sum \* 31/);
assert.match(protocol, /% 1679615/);
assert.match(protocol, /payload:byte\(i\)/);

const calendar = fs.readFileSync(path.join(root, 'Calendar.lua'), 'utf8');
const ui = fs.readFileSync(path.join(root, 'UI.lua'), 'utf8');
const database = fs.readFileSync(path.join(root, 'Database.lua'), 'utf8');
const slash = fs.readFileSync(path.join(root, 'Slash.lua'), 'utf8');
const core = fs.readFileSync(path.join(root, 'Core.lua'), 'utf8');
const protocolSource = fs.readFileSync(path.join(root, 'Protocol.lua'), 'utf8');
const raidExecutor = fs.readFileSync(path.join(root, 'RaidExecutor.lua'), 'utf8');
const controller = fs.readFileSync(path.join(root, 'Controller.lua'), 'utf8');
const calendarInviteQueue = fs.readFileSync(path.join(root, 'CalendarInviteQueue.lua'), 'utf8');

assert.match(core, /WA\.version = "2\.1\.0-beta\.7"/);
assert.match(ui, /edit:EnableKeyboard\(true\)/,
  'code inputs must explicitly accept keyboard input');
assert.match(ui, /scroll:SetScript\("OnMouseDown", function\(\) edit:SetFocus\(\) end\)/,
  'clicking the code input scroll area must focus its edit box');
assert.doesNotMatch(ui, /귓속말 자동 초대|toolsPanel/,
  'unapproved whisper invite controls must not appear in the release UI');
assert.doesNotMatch(slash, /command == "auto"|command == "keyword"/,
  'unapproved whisper invite commands must not be exposed');
assert.match(ui, /CreateMaskTexture/,
  'minimap button must use a clean circular WANION treatment');
assert.doesNotMatch(ui, /local ring =/,
  'minimap button must not render the old square violet backing');
assert.match(protocolSource, /if #entries == 0 then return nil/,
  'empty INV and SORT rosters must be rejected');
assert.match(protocolSource, /#hex ~= 2 or not hex:match\("\^%x%x\$"\)/,
  'percent encoded CAL fields must reject truncated escapes');
assert.match(raidExecutor, /not assignments\[candidate\.key\] or assignments\[candidate\.key\] == target\.subgroup/,
  'full target groups must allow safe swaps with unassigned members');
assert.match(controller, /WA\.CalendarInviteQueue:Stop/,
  'global cancel must also stop calendar invites');

for (const forbiddenAutoSave of [
  /C_Calendar\.AddEvent\s*\(/,
  /C_Calendar\.EventSignUp\s*\(/,
  /CalendarCreateEventCreateButton\s*:\s*Click\s*\(/,
]) {
  assert.doesNotMatch(calendar, forbiddenAutoSave, 'calendar integration must never auto-submit events');
}
assert.ok(
  calendar.indexOf('C_Calendar.EventSetTitle(event.title)') > calendar.indexOf('pcall(CalendarFrame_ShowEventFrame'),
  'calendar fields must be applied after the Blizzard create frame performs its default reset'
);
assert.match(calendar, /CalendarFrame:HookScript\("OnShow"/,
  'calendar side panel must follow CalendarFrame OnShow');
assert.match(calendar, /CalendarFrame:HookScript\("OnHide"/,
  'calendar side panel must follow CalendarFrame OnHide');
assert.match(calendar, /PLAYER_REGEN_ENABLED/,
  'calendar side panel must retry safely after combat');
assert.doesNotMatch(calendar,
  /CalendarFrame\s*:\s*(?:SetPoint|ClearAllPoints|SetParent|SetScale|SetSize|SetWidth|SetHeight|SetScript)\s*\(/,
  'calendar integration must not reposition, resize, reparent, or replace scripts on CalendarFrame');

assert.match(ui, /CreateFrame\("Frame",\s*"WanionAssistCalendarPanel",\s*UIParent/,
  'calendar helper must be a separate UIParent side panel');
assert.match(ui, /RegisterForDrag\("LeftButton"\)/,
  'calendar side panel must support free movement');
assert.match(ui, /mouseButton == "RightButton"/,
  'calendar side panel blank-area right click must reset its position');
assert.match(ui, /calendarPanel\s*=\s*nil/,
  'calendar side panel position reset must clear SavedVariables');
assert.match(ui, /xRatio/);
assert.match(ui, /yRatio/);
assert.match(ui, /GetEffectiveScale/,
  'calendar default docking must account for UI scale differences');
assert.match(ui, /rightDock \+ frame:GetWidth\(\) <= uiWidth/,
  'calendar default docking must verify available right-side space');
assert.match(ui, /elseif leftDock >= 0/,
  'calendar default docking must prefer the left side before overlapping CalendarFrame');
assert.match(ui, /CalendarFrame_GetEventFrame/,
  'calendar helper must dock outside the visible Blizzard event editor/viewer');
assert.match(ui, /달력 일정과 확정 명단 초대/,
  'calendar helper must include an in-addon A-to-Z guide');
assert.match(ui, /파티 배치 A to Z/,
  'raid group editor must include an in-addon A-to-Z guide');
assert.match(calendarInviteQueue, /READY_POLL_SECONDS = 0\.5/,
  'calendar invite queue must poll transient server busy states');
assert.match(calendarInviteQueue, /if not canSendInvite\(\) then[\s\S]*scheduleReadyCheck\(self\)/,
  'calendar invite queue must wait instead of aborting when the server is busy');
assert.doesNotMatch(calendarInviteQueue, /NewTimer\(1\.5/,
  'calendar invite queue must not assume every invite completes within 1.5 seconds');
assert.doesNotMatch(ui, /self:CreateCodePanel\(content,\s*"calendar"/,
  'calendar controls must not live in the main WANION raid-management window');
for (const blizzardTemplate of [
  /UIPanelButtonTemplate/,
  /UIPanelCloseButton/,
  /InputBoxTemplate/,
  /InputScrollFrameTemplate/,
  /UI-DialogBox-Border/,
  /MiniMap-TrackingBorder/,
]) {
  assert.doesNotMatch(ui, blizzardTemplate,
    'WANION interface must not depend on Blizzard-styled buttons, inputs, scrollbars, or borders');
}
assert.match(ui, /SetWanionActive/,
  'WANION tabs must expose a custom active visual state');
assert.match(ui, /local icon = minimapButton:CreateTexture\(nil, "ARTWORK"\)/,
  'minimap icon must render above the violet background texture');
assert.match(database, /db\.ui\.calendarPanel/,
  'calendar side panel SavedVariables must be initialized defensively');
assert.match(slash, /WA\.Calendar:OpenSidePanel\(remainder\)/,
  'calendar slash command must open the dedicated calendar side panel');
for (const alias of ['/wanion', '/wno', '/ㅈ무ㅑㅐㅜ', '/주ㅐ']) {
  assert.ok(slash.includes(`= "${alias}"`), `missing main-window slash alias: ${alias}`);
}

console.log(`PASS: ${expectedModules.length} modules, Lua 5.1 parse, TOC 120007, UTF-8/static/API/side-panel checks, 5 checksum vectors`);
