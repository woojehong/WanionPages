local _, WA = ...

WA.Controller = {}

function WA.Controller:RunCode(raw, mode)
  local parsed, err = WA.Protocol:Parse(raw, mode)
  if not parsed then
    WA:Emit("ACTION_STATUS", err, true)
    return false
  end
  WA.db.lastRaidId = parsed.raidId
  if parsed.mode == "INV" then
    WA.InviteQueue:Start(parsed.entries)
  else
    WA.RaidExecutor:Start(parsed.entries)
  end
  return true
end

function WA.Controller:PreviewSort(raw)
  local parsed, err = WA.Protocol:Parse(raw, "SORT")
  if not parsed then return nil, err end
  local plan, planErr = WA.RaidExecutor:Preview(parsed.entries)
  if not plan then return nil, planErr end
  return ("계획 %d단계 · 명단에 없음 %d명"):format(#plan.steps, #plan.missing)
end

function WA.Controller:PreviewInvite(raw)
  return WA.Operations:PreviewInvite(raw)
end

function WA.Controller:PreviewCalendar(raw)
  local parsed, err = WA.Protocol:ParseCalendar(raw)
  if not parsed then return nil, err end
  return WA.Calendar:Preview(parsed)
end

function WA.Controller:OpenCalendar(raw)
  local parsed, err = WA.Protocol:ParseCalendar(raw)
  if not parsed then
    WA:Emit("ACTION_STATUS", err, true)
    return false
  end
  local opened, message = WA.Calendar:OpenCreateFrame(parsed)
  if opened then WA.Calendar.currentEvent = parsed end
  WA:Emit("ACTION_STATUS", message, not opened)
  return opened
end

function WA.Controller:Snapshot()
  local snapshot = WA.Roster:Capture("snapshot-button")
  if not snapshot.isGroup then return nil, "파티 또는 공격대 상태에서만 스냅샷을 만들 수 있습니다." end
  return WA.Protocol:BuildSnapshot(WA.db.lastRaidId, snapshot)
end

function WA.Controller:Cancel()
  WA.InviteQueue:Stop("초대 큐를 취소했습니다.", false)
  WA.RaidExecutor:Stop("파티 배치를 취소했습니다.", false)
  WA.CalendarInviteQueue:Stop("달력 초대 큐를 취소했습니다.", false)
end

local loader = CreateFrame("Frame")
loader:RegisterEvent("ADDON_LOADED")
loader:RegisterEvent("PLAYER_LOGIN")
loader:SetScript("OnEvent", function(_, eventName, loadedName)
  if eventName == "ADDON_LOADED" and loadedName == WA.name then
    WA.Database:Initialize()
    WA.Roster:Initialize()
    WA.InviteQueue:Initialize()
    WA.CalendarInviteQueue:Initialize()
    WA.RaidExecutor:Initialize()
    WA.Diagnostics:Log("INFO", "LOAD", "핵심 모듈 초기화 완료")
  elseif eventName == "PLAYER_LOGIN" then
    WA.Roster:Capture("PLAYER_LOGIN")
    WA.UI:Build()
    WA.Calendar:Initialize()
    WA.Slash:Initialize()
  end
end)
