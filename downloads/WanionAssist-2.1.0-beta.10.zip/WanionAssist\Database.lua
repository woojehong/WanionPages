local _, WA = ...

WA.Database = {}

local DEFAULTS = {
  inviteTimeout = 8,
  raidStepTimeout = 3,
}

local function numberBetween(value, fallback, low, high)
  value = tonumber(value)
  if not value or value < low or value > high then return fallback end
  return value
end

local function copyTable(source)
  if type(source) ~= "table" then return source end
  local copy = {}
  for key, value in pairs(source) do copy[key] = copyTable(value) end
  return copy
end

function WA.Database:Initialize()
  if type(WanionAssistDB) ~= "table" then WanionAssistDB = {} end
  local db = WanionAssistDB
  local oldSchema = tonumber(db.schemaVersion) or 0

  if oldSchema < WA.schemaVersion and type(db.migrationBackup) ~= "table" then
    db.migrationBackup = {
      schemaVersion = oldSchema,
      mmAngle = db.mmAngle,
      lastRaidId = db.lastRaidId,
      settings = type(db.settings) == "table" and copyTable(db.settings) or nil,
      ui = type(db.ui) == "table" and copyTable(db.ui) or nil,
    }
  end

  db.ui = type(db.ui) == "table" and db.ui or {}
  db.settings = type(db.settings) == "table" and db.settings or {}
  db.ui.minimapAngle = numberBetween(db.ui.minimapAngle or db.mmAngle, 210, -360, 360)
  db.ui.calendarPanel = type(db.ui.calendarPanel) == "table" and db.ui.calendarPanel or nil
  db.ui.calendarPanelDismissed = db.ui.calendarPanelDismissed == true
  db.settings.inviteTimeout = numberBetween(db.settings.inviteTimeout, DEFAULTS.inviteTimeout, 3, 30)
  db.settings.raidStepTimeout = numberBetween(db.settings.raidStepTimeout, DEFAULTS.raidStepTimeout, 1, 10)
  db.settings.whisperInviteEnabled = nil
  db.settings.whisperKeyword = nil
  db.lastRaidId = type(db.lastRaidId) == "string" and db.lastRaidId or "snap"
  db.schemaVersion = WA.schemaVersion
  db.migratedFrom = oldSchema
  db.addonVersion = WA.version
  WA.db = db
end
