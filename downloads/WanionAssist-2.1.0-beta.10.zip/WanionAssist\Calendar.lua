local _, WA = ...

WA.Calendar = {
  frameHooked = false,
  loadHooked = false,
  pendingSync = false,
}

local function inCombat()
  return InCombatLockdown and InCombatLockdown()
end

local function compareDate(a, b)
  if a.year ~= b.year then return a.year < b.year and -1 or 1 end
  if a.month ~= b.month then return a.month < b.month and -1 or 1 end
  if a.monthDay ~= b.monthDay then return a.monthDay < b.monthDay and -1 or 1 end
  return 0
end

local function targetDate(event)
  return { year = event.year, month = event.month, monthDay = event.day }
end

local function loadCalendarUI(requireCreateFrame)
  if inCombat() and not CalendarFrame then
    return false, "전투 중에는 기본 달력 UI를 새로 불러올 수 없습니다. 전투 종료 후 다시 시도하세요."
  end

  if not CalendarFrame then
    if Calendar_LoadUI then
      local ok, err = pcall(Calendar_LoadUI)
      if not ok then return false, tostring(err) end
    elseif C_AddOns and C_AddOns.LoadAddOn then
      local ok, loaded, reason = pcall(C_AddOns.LoadAddOn, "Blizzard_Calendar")
      if not ok or loaded == false then return false, tostring(reason or loaded) end
    elseif LoadAddOn then
      local ok, loaded, reason = pcall(LoadAddOn, "Blizzard_Calendar")
      if not ok or loaded == false then return false, tostring(reason or loaded) end
    end
  end

  if not CalendarFrame then
    return false, "기본 달력 화면을 불러오지 못했습니다."
  end
  if requireCreateFrame and (not CalendarCreateEventFrame or not CalendarFrame_ShowEventFrame) then
    return false, "기본 달력 작성 화면을 불러오지 못했습니다."
  end
  return true
end

local function findDayButton(day)
  for index = 1, 42 do
    local control = _G["CalendarDayButton" .. index]
    if control and control.day == day and control.monthOffset == 0 then return control end
  end
end

local function descriptionWithLink(event)
  local description = WA.Trim(event.description)
  local link = WA.Trim(event.link)
  if link == "" then return description end
  if description == "" then return "와니온: " .. link end
  return description .. "\n\n와니온: " .. link
end

function WA.Calendar:SyncSidePanel()
  if not CalendarFrame or not CalendarFrame.IsShown then
    if WA.UI and WA.UI.calendarFrame then WA.UI.calendarFrame:Hide() end
    return false, "기본 달력 프레임이 없습니다."
  end

  if not CalendarFrame:IsShown() then
    if WA.UI and WA.UI.calendarFrame then WA.UI.calendarFrame:Hide() end
    return true
  end

  if WA.db and WA.db.ui and WA.db.ui.calendarPanelDismissed == true then
    if WA.UI and WA.UI.calendarFrame then WA.UI.calendarFrame:Hide() end
    return true
  end

  if not WA.UI or not WA.UI.BuildCalendarPanel then
    self.pendingSync = true
    return false, "와니온 달력 패널 UI가 아직 준비되지 않았습니다."
  end
  if inCombat() and not WA.UI.calendarFrame then
    self.pendingSync = true
    return false, "전투 중에는 와니온 달력 패널을 처음 만들 수 없습니다."
  end

  local panel = WA.UI:BuildCalendarPanel()
  if not panel then
    self.pendingSync = true
    return false, "와니온 달력 패널을 만들지 못했습니다."
  end

  self.pendingSync = false
  WA.UI:RefreshCalendarPanelPosition()
  panel:Show()
  return true
end

function WA.Calendar:AttachFrameHooks()
  if self.frameHooked or not CalendarFrame or not CalendarFrame.HookScript then return false end

  -- CalendarFrame의 위치·크기·부모·기존 스크립트는 변경하지 않는다.
  CalendarFrame:HookScript("OnShow", function()
    WA.Calendar:SyncSidePanel()
    if C_Timer and C_Timer.After then
      C_Timer.After(0, function()
        if CalendarFrame and CalendarFrame:IsShown() then WA.Calendar:SyncSidePanel() end
      end)
    end
  end)
  CalendarFrame:HookScript("OnHide", function()
    if WA.UI and WA.UI.calendarFrame then WA.UI.calendarFrame:Hide() end
  end)
  for _, eventFrame in ipairs({ CalendarCreateEventFrame, CalendarViewEventFrame }) do
    if eventFrame and eventFrame.HookScript and not eventFrame.__wanionPositionHooked then
      eventFrame.__wanionPositionHooked = true
      eventFrame:HookScript("OnShow", function()
        if WA.UI and WA.UI.RefreshCalendarPanelPosition then WA.UI:RefreshCalendarPanelPosition() end
      end)
      eventFrame:HookScript("OnHide", function()
        if WA.UI and WA.UI.RefreshCalendarPanelPosition then WA.UI:RefreshCalendarPanelPosition() end
      end)
    end
  end
  if CalendarFrame.HookScript then
    CalendarFrame:HookScript("OnSizeChanged", function()
      if WA.UI and WA.UI.RefreshCalendarPanelPosition then WA.UI:RefreshCalendarPanelPosition() end
    end)
  end

  self.frameHooked = true
  self:SyncSidePanel()
  return true
end

function WA.Calendar:Initialize()
  if not self.observer then
    local observer = CreateFrame("Frame")
    observer:RegisterEvent("ADDON_LOADED")
    observer:RegisterEvent("PLAYER_REGEN_ENABLED")
    observer:RegisterEvent("UI_SCALE_CHANGED")
    observer:RegisterEvent("DISPLAY_SIZE_CHANGED")
    observer:SetScript("OnEvent", function(_, eventName, loadedName)
      if eventName == "ADDON_LOADED" and loadedName == "Blizzard_Calendar" then
        WA.Calendar:AttachFrameHooks()
      elseif eventName == "PLAYER_REGEN_ENABLED" then
        if WA.Calendar.pendingSync or (CalendarFrame and CalendarFrame:IsShown()) then
          WA.Calendar:AttachFrameHooks()
          WA.Calendar:SyncSidePanel()
        end
      elseif eventName == "UI_SCALE_CHANGED" or eventName == "DISPLAY_SIZE_CHANGED" then
        if WA.UI and WA.UI.RefreshCalendarPanelPosition then WA.UI:RefreshCalendarPanelPosition() end
      end
    end)
    self.observer = observer
  end

  if not self.loadHooked and hooksecurefunc and Calendar_LoadUI then
    hooksecurefunc("Calendar_LoadUI", function() WA.Calendar:AttachFrameHooks() end)
    self.loadHooked = true
  end
  self:AttachFrameHooks()
end

function WA.Calendar:OpenSidePanel(raw)
  if raw and WA.Trim(raw) ~= "" and WA.UI then WA.UI.pendingCalendarInput = raw end
  if inCombat() then
    return false, "전투 중에는 기본 달력을 열 수 없습니다. 전투 종료 후 다시 시도하세요."
  end

  local loaded, loadErr = loadCalendarUI(false)
  if not loaded then return false, "기본 달력 UI 로드 실패: " .. tostring(loadErr) end
  if WA.db and WA.db.ui then WA.db.ui.calendarPanelDismissed = false end
  self:AttachFrameHooks()

  if not C_Calendar or not C_Calendar.OpenCalendar then
    return false, "이 WoW 클라이언트는 필요한 C_Calendar API를 지원하지 않습니다."
  end
  local openOk, openErr = pcall(C_Calendar.OpenCalendar)
  if not openOk then return false, "달력을 열 수 없습니다: " .. tostring(openErr) end
  if ShowUIPanel then ShowUIPanel(CalendarFrame) else CalendarFrame:Show() end

  local shown, showErr = self:SyncSidePanel()
  if not shown then return false, showErr end
  if raw and WA.Trim(raw) ~= "" then WA.UI:SetInput("calendar", raw) end
  return true, "기본 달력 옆에 와니온 달력 패널을 열었습니다."
end

function WA.Calendar:Preview(event)
  if not event then return nil, "미리 볼 CAL 일정이 없습니다." end
  local description = WA.Trim(event.description)
  local linkStatus = WA.Trim(event.link) ~= "" and "링크 포함" or "링크 없음"
  return ("일정  %04d-%02d-%02d %02d:%02d\n%s\n설명 %d자 · %s · 확정 명단 %d명"):format(
    event.year, event.month, event.day, event.hour, event.minute,
    event.title, #description, linkStatus, #(event.attendees or {})
  )
end

function WA.Calendar:OpenCreateFrame(event)
  if inCombat() then
    return false, "전투 중에는 달력 작성 화면을 열 수 없습니다. 전투 종료 후 다시 시도하세요."
  end
  if not C_Calendar or not C_Calendar.OpenCalendar or not C_Calendar.CreatePlayerEvent
    or not C_Calendar.EventSetDate or not C_Calendar.EventSetTime
    or not C_Calendar.EventSetTitle or not C_Calendar.EventSetDescription then
    return false, "이 WoW 클라이언트는 필요한 C_Calendar API를 지원하지 않습니다."
  end

  local loaded, loadErr = loadCalendarUI(true)
  if not loaded then return false, "기본 달력 UI 로드 실패: " .. tostring(loadErr) end
  self:AttachFrameHooks()

  local currentEventFrame = CalendarFrame_GetEventFrame and CalendarFrame_GetEventFrame()
  if currentEventFrame and currentEventFrame:IsShown() then
    return false, "기본 달력에서 열려 있는 일정을 먼저 저장하거나 닫아주세요."
  end

  local openOk, openErr = pcall(C_Calendar.OpenCalendar)
  if not openOk then return false, "달력을 열 수 없습니다: " .. tostring(openErr) end

  if C_Calendar.GetMinDate and C_Calendar.GetMaxCreateDate then
    local minDate = C_Calendar.GetMinDate()
    local maxDate = C_Calendar.GetMaxCreateDate()
    local wanted = targetDate(event)
    if minDate and compareDate(wanted, minDate) < 0 then
      return false, "지난 날짜에는 새 달력 일정을 만들 수 없습니다."
    end
    if maxDate and compareDate(wanted, maxDate) > 0 then
      return false, "WoW 달력에서 생성할 수 있는 날짜 범위를 벗어났습니다."
    end
  end

  if C_Calendar.CanAddEvent then
    local canCheck, canAdd = pcall(C_Calendar.CanAddEvent)
    if not canCheck or not canAdd then
      return false, "현재 새 달력 일정을 만들 수 없습니다. 잠시 뒤 다시 시도하세요."
    end
  end

  if ShowUIPanel then ShowUIPanel(CalendarFrame) else CalendarFrame:Show() end
  self:SyncSidePanel()
  if C_Calendar.SetAbsMonth then C_Calendar.SetAbsMonth(event.month, event.year) end
  if CalendarFrame_Update then CalendarFrame_Update() end
  local dayButton = findDayButton(event.day)
  if not dayButton then
    return false, "기본 달력에서 대상 날짜를 찾지 못했습니다."
  end

  if C_Calendar.CloseEvent then C_Calendar.CloseEvent() end
  local createOk, createErr = pcall(C_Calendar.CreatePlayerEvent)
  if not createOk then
    if C_Calendar.CloseEvent then C_Calendar.CloseEvent() end
    return false, "달력 일정 후보를 만들지 못했습니다: " .. tostring(createErr)
  end

  CalendarCreateEventFrame.mode = "create"
  CalendarCreateEventFrame.dayButton = dayButton
  local showOk, showErr = pcall(CalendarFrame_ShowEventFrame, CalendarCreateEventFrame)
  if not showOk then
    if C_Calendar.CloseEvent then C_Calendar.CloseEvent() end
    return false, "달력 작성 화면을 표시하지 못했습니다: " .. tostring(showErr)
  end

  local fullDescription = descriptionWithLink(event)
  local fillOk, fillErr = pcall(function()
    C_Calendar.EventSetDate(event.month, event.day, event.year)
    C_Calendar.EventSetTime(event.hour, event.minute)
    C_Calendar.EventSetTitle(event.title)
    C_Calendar.EventSetDescription(fullDescription)
    if C_Calendar.EventSetType and Enum and Enum.CalendarEventType then
      C_Calendar.EventSetType(Enum.CalendarEventType.Other)
    end

    if CalendarCreateEventTitleEdit then CalendarCreateEventTitleEdit:SetText(event.title) end
    local descriptionEdit = CalendarCreateEventDescriptionContainer
      and CalendarCreateEventDescriptionContainer.ScrollingEditBox
      and CalendarCreateEventDescriptionContainer.ScrollingEditBox:GetEditBox()
    if descriptionEdit then descriptionEdit:SetText(fullDescription) end
    CalendarCreateEventFrame.selectedMinute = event.minute
    if CalendarFrame.militaryTime then
      CalendarCreateEventFrame.selectedHour = event.hour
    elseif GameTime_ComputeStandardTime then
      CalendarCreateEventFrame.selectedHour, CalendarCreateEventFrame.selectedAM = GameTime_ComputeStandardTime(event.hour)
    else
      CalendarCreateEventFrame.selectedAM = event.hour < 12
      CalendarCreateEventFrame.selectedHour = event.hour % 12
      if CalendarCreateEventFrame.selectedHour == 0 then CalendarCreateEventFrame.selectedHour = 12 end
    end
    if CalendarCreateEvent_UpdateEventTime then CalendarCreateEvent_UpdateEventTime() end
    if CalendarCreateEventCreateButton_Update then CalendarCreateEventCreateButton_Update() end
  end)
  if not fillOk then
    if CalendarFrame_CloseEvent then CalendarFrame_CloseEvent()
    elseif C_Calendar.CloseEvent then C_Calendar.CloseEvent() end
    return false, "달력 일정 내용을 입력하지 못했습니다: " .. tostring(fillErr)
  end
  WA.Diagnostics:Log("INFO", "CALENDAR", "달력 후보 열기: " .. tostring(event.raidId))
  return true, "기본 달력 작성 화면을 열었습니다. 내용을 확인한 뒤 WoW의 생성 버튼을 눌러 확정하세요."
end
