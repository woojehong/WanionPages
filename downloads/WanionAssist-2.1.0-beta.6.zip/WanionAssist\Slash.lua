local _, WA = ...

WA.Slash = {}

function WA.Slash:Initialize()
  SLASH_WANIONASSIST1 = "/wanion"
  SLASH_WANIONASSIST2 = "/wno"
  SLASH_WANIONASSIST3 = "/ㅈ무ㅑㅐㅜ"
  SLASH_WANIONASSIST4 = "/주ㅐ"
  SlashCmdList.WANIONASSIST = function(message)
    message = WA.Trim(message)
    local command, remainder = message:match("^(%S+)%s*(.-)$")
    command = string.lower(command or "")
    if command == "" or command == "open" then
      WA.UI:Toggle()
    elseif command == "invite" then
      WA.UI:SelectTab("invite")
      WA.UI.frame:Show()
      if remainder ~= "" then WA.UI:SetInput("invite", remainder) end
      WA.Controller:RunCode(WA.UI:GetInput("invite"), "INV")
    elseif command == "sort" then
      WA.UI:SelectTab("raid")
      WA.UI.frame:Show()
      if remainder ~= "" then WA.UI:SetInput("raid", remainder) end
      WA.Controller:RunCode(WA.UI:GetInput("raid"), "SORT")
    elseif command == "snap" then
      WA.UI:SelectTab("snapshot")
      WA.UI.frame:Show()
      local code, err = WA.Controller:Snapshot()
      if code then WA.UI:SetInput("snapshot", code) else WA.UI:SetStatus(err, true) end
    elseif command == "calendar" or command == "cal" then
      local opened, status = WA.Calendar:OpenSidePanel(remainder)
      WA:Emit("ACTION_STATUS", status, not opened)
    elseif command == "diag" then
      WA.UI:SelectTab("diagnostics")
      WA.UI.frame:Show()
      WA.UI:SetInput("diagnostics", WA.Diagnostics:Report())
    elseif command == "cancel" then
      WA.Controller:Cancel()
    elseif command == "retry" then
      WA.InviteQueue:RetryFailed()
    else
      WA.UI:SetStatus("명령: /wanion, invite, retry, sort, snap, calendar, diag, cancel", true)
      WA.UI.frame:Show()
    end
  end
  print("|cff8a70ff와니온 어시스트|r 로드 완료 — 미니맵 버튼 또는 /wanion")
end
