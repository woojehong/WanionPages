local _, WA = ...

WA.Diagnostics = { records = {}, maximum = 40 }

function WA.Diagnostics:Log(level, code, message)
  self.records[#self.records + 1] = {
    at = WA.Now(),
    level = tostring(level),
    code = tostring(code),
    message = tostring(message),
  }
  while #self.records > self.maximum do table.remove(self.records, 1) end
end

function WA.Diagnostics:Report()
  local snapshot = WA.Roster and WA.Roster.current
  local invite = WA.InviteQueue and WA.InviteQueue.state or "미초기화"
  local raid = WA.RaidExecutor and WA.RaidExecutor.state or "미초기화"
  local calendarInvites = WA.CalendarInviteQueue and WA.CalendarInviteQueue.state or "idle"
  local lines = {
    "와니온 어시스트 진단",
    "버전: " .. WA.version,
    "인터페이스: 120007",
    "DB 스키마: " .. tostring(WA.db and WA.db.schemaVersion or "미초기화"),
    "전투 상태: " .. tostring(InCombatLockdown and InCombatLockdown() or false),
    "작업 권한: " .. tostring(WA.IsOperator()),
    "명단 revision/count: " .. tostring(snapshot and snapshot.revision or 0) .. "/" .. tostring(snapshot and snapshot.count or 0),
    "초대 큐: " .. tostring(invite),
    "파티 배치: " .. tostring(raid),
    "달력 초대 큐: " .. tostring(calendarInvites),
    "API/파티 초대: " .. tostring(C_PartyInfo and type(C_PartyInfo.InviteUnit) == "function"),
    "API/달력 초대: " .. tostring(C_Calendar and type(C_Calendar.EventInvite) == "function"),
    "",
    "최근 기록:",
  }
  local startAt = math.max(1, #self.records - 9)
  for i = startAt, #self.records do
    local record = self.records[i]
    lines[#lines + 1] = ("[%s/%s] %s"):format(record.level, record.code, record.message)
  end
  return table.concat(lines, "\n")
end
